package by.g_alex.prog_mob_app.lab1

import android.content.ClipData
import android.content.Context
import android.content.res.Configuration.ORIENTATION_LANDSCAPE
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.ui.tooling.preview.Preview

enum class ValuesTypes {
    LENGTH,
    WEIGHT,
    TEMP
}

data class ValueItem(
    val name: String,
    val toCI: (value: Double) -> Double,
    val fromCI: (value: Double) -> Double,
)

val mapValueName = mapOf(
    Pair(ValuesTypes.TEMP, R.string.title_temp),
    Pair(ValuesTypes.LENGTH, R.string.title_length),
    Pair(ValuesTypes.WEIGHT, R.string.title_weight)
)

val mapOfValuesTypes: MutableMap<ValuesTypes, List<ValueItem>> = mutableMapOf(
    Pair(
        ValuesTypes.TEMP,
        listOf(
            ValueItem(
                name = "°K",
                toCI = { v -> v },
                fromCI = { v -> v }
            ),
            ValueItem(
                name = "°C",
                toCI = { v -> v - 273.15 },
                fromCI = { v -> v + 273.15 }
            ),
            ValueItem(
                name = "°F",
                toCI = { v -> (v - 32) * 5 / 9 - 273.15 },
                fromCI = { v -> (v + 273.15) * 9 / 5 + 32 }
            )
        )
    ),
    Pair(
        ValuesTypes.LENGTH,
        listOf(
            ValueItem(
                name = "m",
                toCI = { v -> v },
                fromCI = { v -> v }
            ),
            ValueItem(
                name = "mm",
                toCI = { v -> v / 1000 },
                fromCI = { v -> v * 1000 }
            ),
            ValueItem(
                name = "cm",
                toCI = { v -> v / 100 },
                fromCI = { v -> v * 100 }
            ),
            ValueItem(
                name = "km",
                toCI = { v -> v * 1000 },
                fromCI = { v -> v / 1000 }
            ),
            ValueItem(
                name = "mile",
                toCI = { v -> v / 0.000621 },
                fromCI = { v -> v * 0.000621 }
            ),
        )
    ),
    Pair(
        ValuesTypes.WEIGHT,
        listOf(
            ValueItem(
                name = "g",
                toCI = { v -> v },
                fromCI = { v -> v }
            ),
            ValueItem(
                name = "mg",
                toCI = { v -> v / 1000 },
                fromCI = { v -> v * 1000 }
            ),
            ValueItem(
                name = "kg",
                toCI = { v -> v * 1000 },
                fromCI = { v -> v / 1000 }
            ),
            ValueItem(
                name = "ft",
                toCI = { v -> v * 453.59237 },
                fromCI = { v -> v / 453.59237 }
            ),
        )
    ),
)

@Composable
@Preview
fun App() {
    MaterialTheme {
        ContentPart()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContentPart() {

    var inputValue by rememberSaveable { mutableStateOf("") }
    var outputValue by rememberSaveable { mutableStateOf("") }

    val selectedType = rememberSaveable { mutableStateOf(ValuesTypes.TEMP) }

    val firstValueSelectedIndex = rememberSaveable { mutableIntStateOf(0) }
    val secondValueSelectedIndex = rememberSaveable { mutableIntStateOf(0) }

    var whatSelect by rememberSaveable { mutableStateOf<Int?>(null) }

    val sheetState = rememberModalBottomSheetState()

    val scope = rememberCoroutineScope()

    var showBottomSheet by rememberSaveable { mutableStateOf(false) }

    val configuration = LocalConfiguration.current.orientation

    val some = @Composable {
        Box(
            modifier = Modifier.fillMaxWidth(
                if (configuration == ORIENTATION_LANDSCAPE) 0.5f else 1.0f
            )
        ) {
            MainContent(
                inputValue = inputValue,
                outputValue = outputValue,
                selectedTypeF = selectedType,
                firstValueSelected = firstValueSelectedIndex,
                secondValueSelected = secondValueSelectedIndex,
                whatSelect = whatSelect,
                setWhatSelect = { whatSelect = it; showBottomSheet = true }
            ) {
                outputValue = it
            }
        }
        KeyBoard(
            onSymbleClick = { c ->
                if (c == '.' && (c in inputValue || inputValue.isEmpty())) return@KeyBoard
                inputValue += c
            },
            onDelClick = {
                if (inputValue.isEmpty()) return@KeyBoard
                inputValue = inputValue.dropLast(1)
            }
        )
    }

    Scaffold { padding ->

        if (showBottomSheet) {
            ModalBottomSheet(
                onDismissRequest = {
                    showBottomSheet = false
                },
                sheetState = sheetState
            ) {
                SelectValues(
                    mapOfValuesTypes[selectedType.value]!!
                ) {
                    if (whatSelect == 1) {
                        firstValueSelectedIndex.intValue = it
                    } else if (whatSelect == 2) {
                        secondValueSelectedIndex.intValue = it
                    }
                    scope.launch {
                        sheetState.hide()
                    }.invokeOnCompletion {
                        if (!sheetState.isVisible)
                            showBottomSheet = false
                    }
                    whatSelect = null
                }
            }
        }


        if (configuration != ORIENTATION_LANDSCAPE) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) { some() }
        } else {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) { some() }
        }
    }
}

@Composable
private fun MainContent(
    inputValue: String,
    outputValue: String,
    selectedTypeF: MutableState<ValuesTypes>,
    firstValueSelected: MutableIntState,
    secondValueSelected: MutableIntState,
    whatSelect: Int?,
    setWhatSelect: (value: Int) -> Unit,
    setOutput: (value: String) -> Unit
) {

    var firstValueSelectedIndex by rememberSaveable { firstValueSelected }
    var secondValueSelectedIndex by rememberSaveable { secondValueSelected }

    var selectedType by rememberSaveable { selectedTypeF }

    val change = {
        val tmp = inputValue.toDoubleOrNull()
        if (tmp == null) {
            setOutput("")
        } else {

            val inp = mapOfValuesTypes[selectedType]?.getOrNull(firstValueSelectedIndex)?.toCI?.let { it(tmp) }
                ?: 0.0
            val out = mapOfValuesTypes[selectedType]?.getOrNull(secondValueSelectedIndex)?.fromCI?.let { it(inp) }
                ?: 0.0

            setOutput(out.toString())
        }
    }

    LaunchedEffect(selectedType) {
        firstValueSelectedIndex = 0
        secondValueSelectedIndex = 0
        change()
    }

    LaunchedEffect(inputValue, whatSelect) {
        change()
    }

    Column(
        modifier = Modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier.fillMaxWidth()
        ) {
            mapValueName.keys.forEachIndexed { index, elem ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index, mapValueName.size),
                    onClick = {
                        if (selectedType == elem) return@SegmentedButton
                        selectedType = elem
                    },
                    selected = selectedType == elem
                ) {
                    Text(stringResource(mapValueName[elem]!!))
                }
            }
        }
        InputFieldItem(
            inputValue,
            mapOfValuesTypes[selectedType]?.getOrNull(firstValueSelectedIndex)
        ) { setWhatSelect(1) }

        IconButton(
            onClick = {
                val tmp = firstValueSelectedIndex
                firstValueSelectedIndex = secondValueSelectedIndex
                secondValueSelectedIndex = tmp
                change()
            },
        ) {
            Icon(painterResource(R.drawable.swap), null)
        }

        InputFieldItem(
            outputValue,
            mapOfValuesTypes[selectedType]?.getOrNull(secondValueSelectedIndex)
        ) { setWhatSelect(2) }
    }
}

@Composable
private fun SelectValues(
    listOfValues: List<ValueItem>,
    onSelectValueClick: (index: Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        listOfValues.forEachIndexed { index, value ->
            OutlinedCard(
                onClick = { onSelectValueClick(index) },
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp, horizontal = 8.dp),
            ) {
                Text(
                    text = value.name,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                )
            }
        }
    }
}

@Composable
private fun InputFieldItem(
    text: String,
    selectedValue: ValueItem?,
    onSelectValueClick: () -> Unit
) {

    val clipboardManager = LocalClipboardManager.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = text,
            readOnly = true,
            onValueChange = {},
            trailingIcon = {
                IconButton(onClick = {
                    clipboardManager.setText(AnnotatedString(text))
                }) {
                    Icon(
                        painterResource(R.drawable.copy), null
                    )
                }
            }
        )

        FilledTonalButton(
            onClick = onSelectValueClick
        ) {
            selectedValue?.name?.let { Text(it) }
        }
    }
}


@Composable
private fun KeyBoard(
    onSymbleClick: (c: Char) -> Unit,
    onDelClick: () -> Unit
) {
    val list = mutableListOf<Char>()
    list.addAll('1'..'9')
    list.add('.')
    list.add('0')
    LazyVerticalGrid(columns = GridCells.Fixed(3)) {
        list.forEach {
            item {
                SampleButton(it.toString()) {
                    onSymbleClick(it)
                }
            }
        }

        item {
            SampleButton("Del") { onDelClick() }
        }
    }
}

@Composable
fun SampleButton(
    text: String,
    onClick: () -> Unit
) {
    FilledTonalButton(
        onClick = onClick,
        modifier = Modifier.padding(4.dp)
    ) {
        Text(text)
    }
}
