import os
import shutil
import hashlib
import configparser
from datetime import datetime, timedelta
import logging
from logging.handlers import TimedRotatingFileHandler
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
import re
import glob

CONFIG_FILE = "backup.conf"
TIME_FORMAT = "%Y-%m-%d-%H-%M-%S"  # Единый формат времени для всего приложения

class BackupApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Backup System")
        self.geometry("600x500")
        
        # Создаем вкладки для разделения функционала
        self.tab_control = ttk.Notebook(self)
        
        # Вкладка бэкапа
        self.backup_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.backup_tab, text='Создание бэкапа')
        
        # Вкладка восстановления
        self.restore_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.restore_tab, text='Восстановление')
        
        self.tab_control.pack(expand=1, fill='both')
        
        # Настройка вкладки бэкапа
        self.setup_backup_tab()
        
        # Настройка вкладки восстановления
        self.setup_restore_tab()
    
    def setup_backup_tab(self):
        # Создаем и размещаем виджеты на вкладке бэкапа
        self.source_label = tk.Label(self.backup_tab, text="Исходная директория:")
        self.source_label.pack(anchor='w', padx=10, pady=(10, 0))
        
        source_frame = tk.Frame(self.backup_tab)
        source_frame.pack(fill='x', padx=10, pady=5)
        
        self.source_entry = tk.Entry(source_frame, width=50)
        self.source_entry.pack(side='left', fill='x', expand=True)
        
        self.source_button = tk.Button(source_frame, text="Обзор", command=self.browse_source)
        self.source_button.pack(side='right', padx=5)
        
        self.backup_label = tk.Label(self.backup_tab, text="Директория для бэкапов:")
        self.backup_label.pack(anchor='w', padx=10, pady=(10, 0))
        
        backup_frame = tk.Frame(self.backup_tab)
        backup_frame.pack(fill='x', padx=10, pady=5)
        
        self.backup_entry = tk.Entry(backup_frame, width=50)
        self.backup_entry.pack(side='left', fill='x', expand=True)
        
        self.backup_button = tk.Button(backup_frame, text="Обзор", command=self.browse_backup)
        self.backup_button.pack(side='right', padx=5)
        
        # Настройки сроков хранения
        retention_frame = tk.Frame(self.backup_tab)
        retention_frame.pack(fill='x', padx=10, pady=10)
        
        self.retention_label = tk.Label(retention_frame, text="Срок хранения (дней):")
        self.retention_label.pack(side='left', padx=(0, 5))
        
        self.retention_entry = tk.Entry(retention_frame, width=5)
        self.retention_entry.pack(side='left')
        self.retention_entry.insert(0, "7")
        
        self.interval_label = tk.Label(retention_frame, text="Интервал второго уровня (дней):")
        self.interval_label.pack(side='left', padx=(20, 5))
        
        self.interval_entry = tk.Entry(retention_frame, width=5)
        self.interval_entry.pack(side='left')
        self.interval_entry.insert(0, "14")
        
        # Кнопка запуска бэкапа
        self.run_button = tk.Button(
            self.backup_tab, 
            text="Создать бэкап", 
            command=self.run_backup,
            bg="#4CAF50", 
            fg="white", 
            font=("Arial", 12, "bold"),
            padx=20
        )
        self.run_button.pack(pady=20)
        
        # Область статуса
        self.status_frame = tk.LabelFrame(self.backup_tab, text="Статус")
        self.status_frame.pack(fill='x', padx=10, pady=10, expand=True)
        
        self.status_text = tk.Text(self.status_frame, height=8, wrap=tk.WORD)
        self.status_text.pack(fill='both', expand=True, padx=5, pady=5)
        self.status_text.config(state=tk.DISABLED)

    def setup_restore_tab(self):
        # Создаем и размещаем виджеты на вкладке восстановления
        self.restore_source_label = tk.Label(self.restore_tab, text="Директория с бэкапами:")
        self.restore_source_label.pack(anchor='w', padx=10, pady=(10, 0))
        
        restore_source_frame = tk.Frame(self.restore_tab)
        restore_source_frame.pack(fill='x', padx=10, pady=5)
        
        self.restore_source_entry = tk.Entry(restore_source_frame, width=50)
        self.restore_source_entry.pack(side='left', fill='x', expand=True)
        
        self.restore_source_button = tk.Button(restore_source_frame, text="Обзор", command=self.browse_restore_source)
        self.restore_source_button.pack(side='right', padx=5)
        
        self.restore_target_label = tk.Label(self.restore_tab, text="Директория для восстановления:")
        self.restore_target_label.pack(anchor='w', padx=10, pady=(10, 0))
        
        restore_target_frame = tk.Frame(self.restore_tab)
        restore_target_frame.pack(fill='x', padx=10, pady=5)
        
        self.restore_target_entry = tk.Entry(restore_target_frame, width=50)
        self.restore_target_entry.pack(side='left', fill='x', expand=True)
        
        self.restore_target_button = tk.Button(restore_target_frame, text="Обзор", command=self.browse_restore_target)
        self.restore_target_button.pack(side='right', padx=5)
        
        # Добавляем фрейм для списка бэкапов и их выбора
        backup_list_frame = tk.LabelFrame(self.restore_tab, text="Доступные бэкапы")
        backup_list_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Добавляем toolbar с кнопками обновления списка бэкапов
        toolbar_frame = tk.Frame(backup_list_frame)
        toolbar_frame.pack(fill='x', padx=5, pady=5)
        
        self.refresh_button = tk.Button(
            toolbar_frame, 
            text="Обновить список", 
            command=self.refresh_backup_list
        )
        self.refresh_button.pack(side='left')
        
        # Добавляем Treeview для отображения бэкапов
        self.tree_frame = tk.Frame(backup_list_frame)
        self.tree_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Создаем скроллбар
        scrollbar = tk.Scrollbar(self.tree_frame)
        scrollbar.pack(side='right', fill='y')
        
        # Создаем Treeview с прокруткой
        self.backup_tree = ttk.Treeview(
            self.tree_frame,
            columns=("date", "path"),
            show="headings",
            yscrollcommand=scrollbar.set
        )
        
        # Настраиваем столбцы
        self.backup_tree.heading("date", text="Дата бэкапа")
        self.backup_tree.heading("path", text="Путь")
        
        self.backup_tree.column("date", width=150)
        self.backup_tree.column("path", width=400)
        
        self.backup_tree.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.backup_tree.yview)
        
        # Кнопка восстановления выбранного бэкапа
        self.restore_button = tk.Button(
            self.restore_tab, 
            text="Восстановить выбранный бэкап", 
            command=self.restore_backup,
            bg="#2196F3", 
            fg="white", 
            font=("Arial", 12, "bold"),
            padx=20
        )
        self.restore_button.pack(pady=20)
        
        # Область статуса восстановления
        self.restore_status_frame = tk.LabelFrame(self.restore_tab, text="Статус восстановления")
        self.restore_status_frame.pack(fill='x', padx=10, pady=10)
        
        self.restore_status_text = tk.Text(self.restore_status_frame, height=5, wrap=tk.WORD)
        self.restore_status_text.pack(fill='both', expand=True, padx=5, pady=5)
        self.restore_status_text.config(state=tk.DISABLED)

    def browse_source(self):
        source_dir = filedialog.askdirectory()
        if source_dir:
            self.source_entry.delete(0, tk.END)
            self.source_entry.insert(0, source_dir)

    def browse_backup(self):
        backup_dir = filedialog.askdirectory()
        if backup_dir:
            self.backup_entry.delete(0, tk.END)
            self.backup_entry.insert(0, backup_dir)

    def browse_restore_source(self):
        restore_source_dir = filedialog.askdirectory()
        if restore_source_dir:
            self.restore_source_entry.delete(0, tk.END)
            self.restore_source_entry.insert(0, restore_source_dir)
            # Автоматически обновляем список бэкапов
            self.refresh_backup_list()

    def browse_restore_target(self):
        restore_target_dir = filedialog.askdirectory()
        if restore_target_dir:
            self.restore_target_entry.delete(0, tk.END)
            self.restore_target_entry.insert(0, restore_target_dir)

    def add_status_message(self, message, status_text_widget):
        status_text_widget.config(state=tk.NORMAL)
        timestamp = datetime.now().strftime(TIME_FORMAT)
        status_text_widget.insert(tk.END, f"{timestamp} - {message}\n")
        status_text_widget.see(tk.END)
        status_text_widget.config(state=tk.DISABLED)
        self.update_idletasks()  # Обновляем UI

    def refresh_backup_list(self):
        backup_dir = self.restore_source_entry.get()
        if not backup_dir or not os.path.exists(backup_dir):
            messagebox.showerror("Ошибка", "Пожалуйста, укажите существующую директорию с бэкапами")
            return
        
        # Очищаем текущий список
        for item in self.backup_tree.get_children():
            self.backup_tree.delete(item)
        
        self.add_status_message(f"Поиск бэкапов в {backup_dir}...", self.restore_status_text)
        
        # Словарь для хранения уникальных дат бэкапов
        backup_dates = {}
        
        # Ищем все файлы с датой бэкапа в имени
        for root, _, files in os.walk(backup_dir):
            for file in files:
                # Используем новый формат времени в регулярном выражении
                match = re.search(r'_(\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2})\.\w+$', file)
                if match:
                    date_str = match.group(1)
                    try:
                        backup_date = datetime.strptime(date_str, TIME_FORMAT)
                        formatted_date = backup_date.strftime(TIME_FORMAT)
                        
                        # Если дата еще не добавлена, создаем новую запись
                        if formatted_date not in backup_dates:
                            rel_path = os.path.relpath(root, backup_dir)
                            if rel_path == ".":
                                display_path = backup_dir
                            else:
                                display_path = os.path.join(backup_dir, rel_path)
                            
                            backup_dates[formatted_date] = {
                                "date": backup_date,
                                "path": display_path
                            }
                    except ValueError:
                        continue
        
        # Сортируем даты по убыванию (сначала новые)
        sorted_dates = sorted(backup_dates.items(), key=lambda x: x[1]["date"], reverse=True)
        
        # Заполняем дерево
        for formatted_date, info in sorted_dates:
            self.backup_tree.insert("", "end", values=(formatted_date, info["path"]))
        
        count = len(backup_dates)
        self.add_status_message(f"Найдено {count} уникальных бэкапов", self.restore_status_text)

    def run_backup(self):
        source_path = self.source_entry.get()
        backup_path = self.backup_entry.get()
        
        if not source_path or not os.path.exists(source_path):
            messagebox.showerror("Ошибка", "Пожалуйста, укажите существующую исходную директорию")
            return
            
        if not backup_path:
            messagebox.showerror("Ошибка", "Пожалуйста, укажите директорию для бэкапов")
            return
        
        try:
            retention_days = int(self.retention_entry.get())
            interval_days = int(self.interval_entry.get())
        except ValueError:
            messagebox.showerror("Ошибка", "Срок хранения и интервал должны быть числами")
            return
        
        # Создаем и сохраняем конфигурацию
        config = configparser.ConfigParser()
        if not config.has_section("backup"):
            config.add_section("backup")
            
        if not config.has_section("timeframes"):
            config.add_section("timeframes")
            
        config["backup"]["source_path"] = source_path
        config["backup"]["backup_path"] = backup_path
        config["timeframes"]["backup_retention_time"] = f"{retention_days}d"
        config["timeframes"]["second_stage_backup_interval"] = f"{interval_days}d"
        
        with open(CONFIG_FILE, "w") as f:
            config.write(f)
        
        # Настраиваем логирование в GUI
        class TextHandler(logging.Handler):
            def __init__(self, text_widget):
                logging.Handler.__init__(self)
                self.text_widget = text_widget
                
            def emit(self, record):
                msg = self.format(record)
                def append():
                    self.text_widget.config(state=tk.NORMAL)
                    self.text_widget.insert(tk.END, msg + '\n')
                    self.text_widget.see(tk.END)
                    self.text_widget.config(state=tk.DISABLED)
                self.text_widget.after(0, append)
        
        # Очищаем статус
        self.status_text.config(state=tk.NORMAL)
        self.status_text.delete(1.0, tk.END)
        self.status_text.config(state=tk.DISABLED)
        
        # Настраиваем логгер
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        
        # Удаляем все обработчики
        for handler in logger.handlers[:]:
            logger.removeHandler(handler)
            
        # Добавляем обработчик для текстового виджета
        text_handler = TextHandler(self.status_text)
        text_handler.setFormatter(logging.Formatter(f'%(asctime)s - %(levelname)s - %(message)s', datefmt=TIME_FORMAT))
        logger.addHandler(text_handler)
        
        # Добавляем обработчик для файла
        file_handler = TimedRotatingFileHandler("backup.log", when='d', interval=1, backupCount=7)
        file_handler.setFormatter(logging.Formatter(f'%(asctime)s - %(levelname)s - %(message)s', datefmt=TIME_FORMAT))
        logger.addHandler(file_handler)
        
        # Запускаем бэкап в отдельном потоке, чтобы не блокировать GUI
        import threading
        backup_thread = threading.Thread(target=perform_backup)
        backup_thread.daemon = True
        backup_thread.start()
        
        self.add_status_message("Процесс бэкапа запущен...", self.status_text)

    def restore_backup(self):
        selected_items = self.backup_tree.selection()
        if not selected_items:
            messagebox.showerror("Ошибка", "Пожалуйста, выберите бэкап для восстановления")
            return
        
        selected_item = selected_items[0]
        selected_values = self.backup_tree.item(selected_item, "values")
        
        backup_date_str = selected_values[0]
        backup_path = selected_values[1]
        
        target_path = self.restore_target_entry.get()
        if not target_path:
            messagebox.showerror("Ошибка", "Пожалуйста, укажите директорию для восстановления")
            return
            
        if not os.path.exists(target_path):
            try:
                os.makedirs(target_path)
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось создать директорию для восстановления: {e}")
                return
        
        # Запрашиваем подтверждение
        confirm = messagebox.askyesno(
            "Подтверждение", 
            f"Вы уверены, что хотите восстановить бэкап от {backup_date_str} в {target_path}?\n\n"
            "Существующие файлы могут быть перезаписаны."
        )
        
        if not confirm:
            return
        
        # Настраиваем логирование
        self.restore_status_text.config(state=tk.NORMAL)
        self.restore_status_text.delete(1.0, tk.END)
        self.restore_status_text.config(state=tk.DISABLED)
        
        self.add_status_message(f"Начало восстановления бэкапа от {backup_date_str}...", self.restore_status_text)
        
        # Используем дату в формате TIME_FORMAT
        backup_date_pattern = backup_date_str  # Уже в формате TIME_FORMAT
        
        # Восстановление запускаем в отдельном потоке
        import threading
        restore_thread = threading.Thread(
            target=self.perform_restore, 
            args=(backup_path, target_path, backup_date_pattern)
        )
        restore_thread.daemon = True
        restore_thread.start()

    def perform_restore(self, backup_path, target_path, backup_date_pattern):
        try:
            # Счетчики для статистики
            files_restored = 0
            
            # Пройдем по всем файлам в директории бэкапа
            for root, _, files in os.walk(backup_path):
                for file in files:
                    # Ищем файлы с нужной датой бэкапа
                    if f"_{backup_date_pattern}" in file:
                        # Получаем полный путь к файлу бэкапа
                        backup_file_path = os.path.join(root, file)
                        
                        # Получаем относительный путь от корня бэкапов
                        rel_path = os.path.relpath(root, backup_path)
                        
                        # Получаем имя файла без даты бэкапа
                        original_file_name = re.sub(f"_+{backup_date_pattern}", "", file)
                        
                        # Определяем путь в целевой директории
                        target_dir = target_path
                        if rel_path != ".":
                            target_dir = os.path.join(target_path, rel_path)
                            
                        # Создаем директорию, если она не существует
                        os.makedirs(target_dir, exist_ok=True)
                        
                        # Полный путь целевого файла
                        target_file_path = os.path.join(target_dir, original_file_name)
                        
                        # Копируем файл
                        shutil.copy2(backup_file_path, target_file_path)
                        files_restored += 1
                        
                        self.add_status_message(f"Восстановлен: {target_file_path}", self.restore_status_text)
            
            self.add_status_message(f"Восстановление завершено. Восстановлено файлов: {files_restored}", self.restore_status_text)
            messagebox.showinfo("Восстановление завершено", f"Восстановлено {files_restored} файлов")
            
        except Exception as e:
            error_msg = f"Ошибка при восстановлении: {e}"
            self.add_status_message(error_msg, self.restore_status_text)
            messagebox.showerror("Ошибка", error_msg)


def parse_timeframe(timeframe):
    try:
        duration = int(timeframe[:-1])
        unit = timeframe[-1]
        
        if unit == "h":
            return timedelta(hours=duration)
        elif unit == "d":
            return timedelta(days=duration)
        else:
            raise ValueError("Invalid time frame unit. Only 'h' (hours) and 'd'(days) are supported.")
    except (ValueError, IndexError):
        logging.error(f"Invalid timeframe format: {timeframe}")
        return timedelta(days=7)  # Default to 7 days

def generate_hash(file_path):
    hasher = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hasher.update(chunk)
    return hasher.hexdigest()

def create_backup(source_path, backup_path, last_backup_time):
    current_time = datetime.now()
    backup_time_str = current_time.strftime(TIME_FORMAT)
    
    for root, _, files in os.walk(source_path):
        for file in files:
            file_path = os.path.join(root, file)
            rel_path = os.path.relpath(root, source_path)
            backup_dir = os.path.join(backup_path, rel_path)
            
            # Создаем каталоги, если они не существуют
            os.makedirs(backup_dir, exist_ok=True)
            
            modified_time = datetime.fromtimestamp(os.path.getmtime(file_path))
            
            if modified_time > last_backup_time or last_backup_time == datetime.min:
                file_name, file_ext = os.path.splitext(file)
                new_file_name = f"{file_name}_{backup_time_str}{file_ext}"
                backup_file_path = os.path.join(backup_dir, new_file_name)
                
                shutil.copy2(file_path, backup_file_path)
                logging.info(f"Backed up: {file_path} -> {backup_file_path}")
            else:
                logging.debug(f"No changes detected: {file_path}")

def remove_old_backups(backup_path, retention_time, second_stage_interval):
    oldest_allowed_time = datetime.now() - retention_time
    
    for root, dirs, files in os.walk(backup_path):
        for file in files:
            if "_" in file:
                try:
                    # Ищем дату в формате TIME_FORMAT
                    match = re.search(r'_(\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2})\.\w+$', file)
                    if match:
                        date_str = match.group(1)
                        backup_time = datetime.strptime(date_str, TIME_FORMAT)
                        
                        if backup_time < oldest_allowed_time:
                            # Если файл старше retention_time
                            days_old = (datetime.now() - backup_time).days
                            # Сохраняем каждый second_stage_interval дней
                            if second_stage_interval.days > 0 and days_old % second_stage_interval.days == 0:
                                logging.debug(f"Keeping second-stage backup: {file}")
                                continue
                                
                            file_path = os.path.join(root, file)
                            os.remove(file_path)
                            logging.info(f"Removed old backup: {file_path}")
                except (ValueError, IndexError) as e:
                    logging.warning(f"Could not parse backup date from {file}: {e}")

def perform_backup():
    # Проверяем существование конфигурационного файла
    if not os.path.exists(CONFIG_FILE):
        logging.error(f"Configuration file {CONFIG_FILE} not found")
        return
    
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE)
    
    try:
        source_path = config.get("backup", "source_path")
        backup_path = config.get("backup", "backup_path")
        backup_retention_time = parse_timeframe(config.get("timeframes", "backup_retention_time"))
        second_stage_backup_interval = parse_timeframe(config.get("timeframes", "second_stage_backup_interval"))
        
        if not os.path.exists(source_path):
            logging.error(f"Source path does not exist: {source_path}")
            return
            
        if not os.path.exists(backup_path):
            os.makedirs(backup_path)
            
        try:
            last_backup_time_str = config.get("backup", "last_backup_time")
            last_backup_time = datetime.strptime(last_backup_time_str, TIME_FORMAT)
        except (configparser.NoOptionError, ValueError):
            last_backup_time = datetime.min
        
        logging.info("Starting backup process...")
        logging.info(f"Source Path: {source_path}")
        logging.info(f"Backup Path: {backup_path}")
        logging.info(f"Backup Retention Time: {backup_retention_time}")
        logging.info(f"Second Stage Backup Interval: {second_stage_backup_interval}")
        
        create_backup(source_path, backup_path, last_backup_time)
        
        # Теперь вызываем функцию для удаления старых бэкапов
        remove_old_backups(backup_path, backup_retention_time, second_stage_backup_interval)
        
        # Обновляем время последнего бэкапа
        if not config.has_section("backup"):
            config.add_section("backup")
            
        config.set("backup", "last_backup_time", datetime.now().strftime(TIME_FORMAT))
        
        with open(CONFIG_FILE, "w") as f:
            config.write(f)
            
        logging.info("Backup process completed.")
        
    except Exception as e:
        logging.error(f"Error during backup: {e}")

if __name__ == "__main__":
    app = BackupApp()
    app.mainloop()
