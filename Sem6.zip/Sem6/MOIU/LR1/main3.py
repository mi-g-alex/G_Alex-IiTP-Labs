import numpy as np
from main2 import solve

def initial_simplex_phase(c, A, b):
    # step 1 Корректировка правых частей
    m, n = A.shape
    for i in range(m):
        if b[i] < 0:
            A[i] *= -1
            b[i] *= -1

    # step 2 Формирование вспомогательной задачи
    zeros = np.zeros(n, dtype=int)
    minus_ones = np.full(m, -1, dtype=int)
    c_temp = np.concatenate((zeros, minus_ones))
    identity_matrix = np.eye(m)
    A_temp = np.hstack((A, identity_matrix))

    # step 3 Начальный базисный план для вспомогательной задачи
    x_temp = np.concatenate((zeros, b))
    B_temp = np.arange(n + 1, n + m + 1)

    # step 4
    solved_x, solved_B = solve(A_temp, B_temp, c_temp, x_temp)
    
    # Шаг 5: Проверка на совместимость
    if not np.all(solved_x[n + 1:n + m + 1] == 0):
        print("Задача несовместна.")
        return None, None
    
    # step 6 Формирование начального плана для исходной задачи
    result_x = x_temp[:n]
    B_temp -= 1

    # step 7-9 Удаление искусственных переменных из базиса
    while not check_B(B_temp, n):

        jk = np.max(B_temp)
        k = np.argmax(B_temp)
        i = jk - n

        all_numbers = np.arange(0, n)
        all_j = all_numbers[~np.isin(all_numbers, b)]

        for index in range(len(all_j)):
            Ab_temp = A_temp[:, B_temp]
            Ab_temp_inv = np.linalg.inv(Ab_temp)
            l = Ab_temp_inv.dot(A_temp[:, all_j[index]])
            if l[k] != 0:
                B_temp[k] = all_j[index]
                break
        else:
            b = np.delete(b, i)
            A = np.delete(A, i, axis=0)
            A_temp = np.delete(A_temp, i, axis=0)
            B_temp = np.delete(B_temp, k)
            
    print("x_t: ", result_x)
    print("B:   ", B_temp + 1)
    print("A:   ", A)
    print("b:   ", b)


def check_B(B, n):
    for i in range(len(B)):
        if B[i] >= n:
            return False
    return True

# Пример
c = [1, 0, 0]
A = np.array([
        [1, 1, 1],
        [2, 2, 2],
    ], dtype=float)
b = np.array(
    [0, -1], 
    dtype=float)

initial_simplex_phase(c, A, b)
