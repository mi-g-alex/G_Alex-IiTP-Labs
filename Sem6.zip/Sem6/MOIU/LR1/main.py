import numpy as np

def process_matrix_and_vector(n, A_inv, i, x):

    l = A_inv @ x

    if l[i] == 0:
        raise ValueError("Матрица не обратима")

    L = l.copy()
    L[i] = -1

    new_column = (-1 / l[i]) * L

    I = np.eye(n)
    I[:, i] = new_column

    result_matrix = np.zeros((n, n))
    for t in range(n):
        for j in range(n):
            result_matrix[t, j] = (
                I[t, t] * A_inv[t, j] + I[t, i] * A_inv[i, j]
                if i != t else
                I[t, i] * A_inv[i, j]
            )

    return result_matrix

def read_data_from_file(filename):
    with open(filename, 'r') as f:
        n = int(f.readline().strip())

        A = np.array([list(map(float, f.readline().strip().split())) for _ in range(n)])

        A_inv = np.array([list(map(float, f.readline().strip().split())) for _ in range(n)])

        i = int(f.readline().strip()) - 1

        x = np.array(list(map(float, f.readline().strip().split())))

    return n, A, A_inv, i, x

filename = 'data.txt'
n, A, A_inv, i, x = read_data_from_file(filename)

try:
    result = process_matrix_and_vector(n, A_inv, i, x)
    A[:, i] = x
    print("Результирующая матрица:\n", result)
except ValueError as e:
    print("Ошибка:", e)