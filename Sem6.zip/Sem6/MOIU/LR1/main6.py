import numpy as np

c = np.array([-8, -6, -3, -6])  
D = np.array([                  
    [2, 1, 1, 0],
    [1, 1, 0, 0],
    [1, 0, 1, 0],
    [0, 0, 0, 0]
])
A = np.array([                  
    [1, 0, 2, 1],
    [0, 1, -1, 2]
])
b = np.array([2, 3])            

x = np.array([2, 3, 0, 0])      
jb = [0, 1]                     
jbs = [0, 1]                

while True:
    # 1 
    # c(x), u(x), delta(x)
    cx = c + D @ x              # Вектор c(x) = c + D x — градиент целевой функции в точке x
    
    # u
    Ab = A[:, jb]               
    cb = cx[jb]                 
    u = -np.linalg.inv(Ab) @ cb # вектор потенциалов для проверки оптимальности

    # delta
    delta = u @ A + cx          
    delta[jbs] = 0          

    # 2 
    if np.all(delta >= 0):      
        print(x)
        break                   

    # 3 
    j0 = np.argmin(delta)       

    # 4 
    h = np.block([
        [D[np.ix_(jbs, jbs)], A[:, jbs].T],  
        [A[:, jbs], np.zeros((A.shape[0], A.shape[0]))] 
    ])
    h_inv = np.linalg.inv(h)  

    bs = np.hstack((D[:, j0][jbs], A[:, j0])) 

    l = -h_inv @ bs         
    ljbs = l[:len(jbs)] 

    l_full = np.zeros_like(x)   
    l_full[jbs] = ljbs  
    l_full[j0] = 1              

    # 5
    delta_j0 = delta[j0]        
    sigma = l_full @ D @ l_full 

    if sigma > 0:               
        theta_j0 = abs(delta_j0) / sigma  
    else:                       
        theta_j0 = np.inf

    theta_j = np.array([-x[j] / l_full[j] if l_full[j] < 0 else np.inf for j in jbs])

    theta_min = min(*theta_j, theta_j0) 

    if theta_min == np.inf:     
        print("Не ограничена снизу на множестве допустимых планов")
        break               

    # 6
    x = x + theta_min * l_full  

    # Обновляем опорные множества jb и jb*
    j_s = np.argmin(np.hstack((theta_j, [theta_j0])))  
    if j_s == len(theta_j):  # Если минимум достигается на theta_j0
        jbs.append(j0)      
    elif jbs[j_s] in jb: # Если j_s в jb (базисная переменная)
        jb[jb.index(jbs[j_s])] = j0 
    else:                       
        jbs.remove(jbs[j_s]) 