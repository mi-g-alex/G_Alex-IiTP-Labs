import re

TOKENS = [
    ('COMMENT', r'!.*'),
    ('SKIP', r'\s+'),            
    ('STRING', r'("(?:""|[^"])*")|(\'(?:\'\'|[^\'])*\')'), 
    ('LOGICAL', r'\.(true|false)\.', re.IGNORECASE),
    ('BINARY', r"[bB]'[01]+'"),
    ('HEX', r"[zZ]'[0-9A-Fa-f]+'"),
    ('FLOAT', r'\d+\.\d*([eEdD][+-]?\d+)?(_\w+)?|\.\d+([eEdD][+-]?\d+)?(_\w+)?|\d+[eEdD][+-]?\d+(_\w+)?'),
    ('INTEGER', r'\d+(_\w+)?'),
    ('OPERATOR', r'(\.(eq|ne|lt|le|gt|ge|and|or|not|eqv|neqv)\.|=>|\*\*|//|/=|==|<=|>=|=|\+|-|\*|/|%|::)', re.IGNORECASE),
    ('PUNCTUATION', r'[(),:;%]'),
    ('KEYWORD', r'\b(program|subroutine|function|end|if|then|else|do|print|read|write|integer|real|character|logical|implicit|none)\b', re.IGNORECASE),
    ('IDENTIFIER', r'[a-zA-Z]\w*'),
]

token_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern, *flags in TOKENS)
token_re = re.compile(token_regex)

def fortran_lexer(code):
    pos = 27
    line_num = 1
    line_start = 0
    tokens = []
    
    while pos <= len(code):
        match = token_re.match(code, pos)
        if not match:
            if pos < len(code):
                raise SyntaxError(f'Unexpected character "{code[pos]}" at line {line_num}')
            break
            
        name = match.lastgroup
        value = match.group(name)
        start = match.start()
        end = match.end()
        column = start - line_start
        
        # Обновление номера строки
        if '\n' in value:
            line_start = end - len(value) + value.rfind('\n') + 1
            line_num += value.count('\n')
        
        if name == 'COMMENT' or name == 'SKIP':
            pos = end
            continue
            
        # Проверка ключевых слов
        if name == 'IDENTIFIER':
            for kw in TOKENS:
                if kw[0] == 'KEYWORD' and re.fullmatch(kw[1], value, kw[2] if len(kw)>2 else 0):
                    name = 'KEYWORD'
                    break
        
        tokens.append({
            'token': name,
            'value': value,
            'line': line_num,
            'column': column +1
        })
        
        pos = end
        
    return tokens

# Пример использования
code = """
subroutine check_even(n)
 implicit none
 integer, intent(in) :: 1n;
 
 if (mod(n, 2) == 0) then
   print *, n, ' - even'
 else
   print *, n, ' - odd'
 end if
end subroutine check_even
 
program main
 implicit none
 integer :: numbers(5);
 integer :: i;
 float :: n = 3;
 integer :: ans = 1;
 
 do i = 1, 5
   numbers(i) = i
 end do
 
 do i = 1, 5
   call check_even(numbers(i))
 end do
 
 do i = n, 1, -1
   ans = ans * i
 end do
 
 print *, ans
end program main
"""

# Запуск лексера
tokens = fortran_lexer(code)

# Вывод таблицы лексем
print("{:<15} {:<20} {:<10} {:<10}".format('Token', 'Value', 'Line', 'Column'))
print('-' *55)
for tok in tokens:
    print("{:<15} {:<20} {:<10} {:<10}".format(
        tok['token'],
        tok['value'],
        tok['line'],
        tok['column']
    ))
    
    


