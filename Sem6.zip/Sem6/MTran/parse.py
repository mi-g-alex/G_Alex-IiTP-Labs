import re
from enum import Enum, auto
import sys

# Типы токенов
class TokenType(Enum):
    PROGRAM = auto()      # Ключевое слово PROGRAM
    END = auto()          # Ключевое слово END
    INTEGER = auto()      # Ключевое слово INTEGER
    REAL = auto()         # Ключевое слово REAL
    LOGICAL = auto()      # Ключевое слово LOGICAL
    IF = auto()           # Ключевое слово IF
    THEN = auto()         # Ключевое слово THEN
    ELSE = auto()         # Ключевое слово ELSE
    ENDIF = auto()        # Ключевое слово ENDIF
    DO = auto()           # Ключевое слово DO
    CONTINUE = auto()     # Ключевое слово CONTINUE
    CALL = auto()         # Ключевое слово CALL
    SUBROUTINE = auto()   # Ключевое слово SUBROUTINE
    FUNCTION = auto()     # Ключевое слово FUNCTION
    RETURN = auto()       # Ключевое слово RETURN
    PRINT = auto()        # Ключевое слово PRINT
    WRITE = auto()        # Ключевое слово WRITE
    READ = auto()         # Ключевое слово READ
    MOD = auto()          # Функция MOD
    IDENTIFIER = auto()   # Идентификатор
    INTEGER_CONST = auto()  # Целочисленная константа
    REAL_CONST = auto()   # Константа с плавающей точкой
    STRING_CONST = auto() # Строковая константа
    COLON = auto()        # :
    DOUBLE_COLON = auto() # ::
    PLUS = auto()         # +
    MINUS = auto()        # -
    MULTIPLY = auto()     # *
    DIVIDE = auto()       # /
    ASSIGN = auto()       # =
    EQ = auto()           # ==
    NE = auto()           # /=
    GT = auto()           # >
    LT = auto()           # <
    GE = auto()           # >=
    LE = auto()           # <=
    LPAREN = auto()       # (
    RPAREN = auto()       # )
    COMMA = auto()        # ,
    SEMICOLON = auto()    # ;
    COMMENT = auto()      # Комментарий
    NEWLINE = auto()      # Перевод строки
    EOF = auto()          # Конец файла
    ERROR = auto()        # Ошибка

# Класс для представления токена
class Token:
    def __init__(self, type, value, line, column):
        self.type = type
        self.value = value
        self.line = line
        self.column = column
    
    def __str__(self):
        return f"Token({self.type}, '{self.value}', line={self.line}, col={self.column})"

# Лексический анализатор
class Lexer:
    # Ключевые слова Fortran
    KEYWORDS = {
        'program': TokenType.PROGRAM,
        'end': TokenType.END,
        'integer': TokenType.INTEGER,
        'real': TokenType.REAL,
        'logical': TokenType.LOGICAL,
        'if': TokenType.IF,
        'then': TokenType.THEN,
        'else': TokenType.ELSE,
        'endif': TokenType.ENDIF,
        'do': TokenType.DO,
        'continue': TokenType.CONTINUE,
        'call': TokenType.CALL,
        'subroutine': TokenType.SUBROUTINE,
        'function': TokenType.FUNCTION,
        'return': TokenType.RETURN,
        'print': TokenType.PRINT,
        'write': TokenType.WRITE,
        'read': TokenType.READ,
        'mod': TokenType.MOD
    }
    
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.line = 1
        self.column = 1
        self.current_char = self.text[self.pos] if self.pos < len(self.text) else None
    
    def process_string(self):
        """Обрабатывает строковые литералы в одинарных кавычках"""
        start_column = self.column
        result = ''
        
        # Пропускаем открывающий апостроф
        self.advance()  
        
        # Читаем содержимое строки до закрывающего апострофа
        while self.current_char is not None and self.current_char != "'":
            # Обработка экранированного апострофа в строке (два апострофа подряд)
            if self.current_char == "'" and self.pos + 1 < len(self.text) and self.text[self.pos + 1] == "'":
                result += "'"
                self.advance()  # Пропускаем первый апостроф
                self.advance()  # Пропускаем второй апостроф
            else:
                result += self.current_char
                self.advance()
        
        # Проверяем, что строка правильно закрыта
        if self.current_char != "'":
            return Token(TokenType.ERROR, result, self.line, start_column)
        
        # Пропускаем закрывающий апостроф
        self.advance()
        
        return Token(TokenType.STRING_CONST, result, self.line, start_column)
    
    def advance(self):
        """Перемещает указатель на следующий символ"""
        if self.current_char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        
        self.pos += 1
        if self.pos >= len(self.text):
            self.current_char = None
        else:
            self.current_char = self.text[self.pos]
    
    def skip_whitespace(self):
        """Пропускает пробельные символы"""
        while self.current_char is not None and self.current_char.isspace() and self.current_char != '\n':
            self.advance()
    
    def process_identifier(self):
        """Обрабатывает идентификаторы и ключевые слова"""
        start_column = self.column
        result = ''
        
        while self.current_char is not None and (self.current_char.isalnum() or self.current_char == '_'):
            result += self.current_char
            self.advance()
        
        # Проверка на ключевое слово
        token_type = self.KEYWORDS.get(result.lower(), TokenType.IDENTIFIER)
        return Token(token_type, result, self.line, start_column)
    
    def process_number(self):
        """Обрабатывает числовые константы"""
        start_column = self.column
        result = ''
        is_real = False
        
        # Цифры перед точкой
        while self.current_char is not None and self.current_char.isdigit():
            result += self.current_char
            self.advance()
        
        # Проверяем, является ли число вещественным
        if self.current_char == '.':
            is_real = True
            result += self.current_char
            self.advance()
            
            # Цифры после точки
            while self.current_char is not None and self.current_char.isdigit():
                result += self.current_char
                self.advance()
        
        # Проверяем экспоненциальную запись
        if self.current_char is not None and self.current_char.lower() == 'e':
            is_real = True
            result += self.current_char
            self.advance()
            
            # Возможный знак в экспоненте
            if self.current_char in ['+', '-']:
                result += self.current_char
                self.advance()
            
            # Цифры в экспоненте
            while self.current_char is not None and self.current_char.isdigit():
                result += self.current_char
                self.advance()
        
        token_type = TokenType.REAL_CONST if is_real else TokenType.INTEGER_CONST
        return Token(token_type, result, self.line, start_column)
    
    def process_comment(self):
        """Обрабатывает комментарии"""
        start_column = self.column
        result = ''
        
        # Пропускаем символ комментария
        self.advance()  # Пропускаем '!'
        
        # Читаем всё до конца строки
        while self.current_char is not None and self.current_char != '\n':
            result += self.current_char
            self.advance()
        
        return Token(TokenType.COMMENT, result, self.line, start_column)
    
    def get_next_token(self):
        """Получает следующий токен из входного текста"""
        while self.current_char is not None:
            # Пропуск пробелов
            if self.current_char.isspace() and self.current_char != '\n':
                self.skip_whitespace()
                continue
            
            # Обработка новой строки
            if self.current_char == '\n':
                line = self.line
                column = self.column
                self.advance()
                return Token(TokenType.NEWLINE, '\n', line, column)
            
            # Обработка идентификаторов и ключевых слов
            if self.current_char.isalpha():
                return self.process_identifier()
            
            # Обработка чисел
            if self.current_char.isdigit():
                return self.process_number()
            
            if self.current_char == ':':
                col = self.column
                self.advance()
                if self.current_char == ':':
                    self.advance()
                    return Token(TokenType.DOUBLE_COLON, '::', self.line, col)
                return Token(TokenType.COLON, ':', self.line, col)
            
            # Обработка комментариев
            if self.current_char == '!':
                return self.process_comment()
            
            # Обработка операторов и символов пунктуации
            if self.current_char == '+':
                col = self.column
                self.advance()
                return Token(TokenType.PLUS, '+', self.line, col)
            
            if self.current_char == '-':
                col = self.column
                self.advance()
                return Token(TokenType.MINUS, '-', self.line, col)
            
            if self.current_char == '*':
                col = self.column
                self.advance()
                return Token(TokenType.MULTIPLY, '*', self.line, col)
            
            if self.current_char == '/':
                col = self.column
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(TokenType.NE, '/=', self.line, col)
                return Token(TokenType.DIVIDE, '/', self.line, col)
            
            if self.current_char == '=':
                col = self.column
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(TokenType.EQ, '==', self.line, col)
                return Token(TokenType.ASSIGN, '=', self.line, col)
            
            if self.current_char == '>':
                col = self.column
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(TokenType.GE, '>=', self.line, col)
                return Token(TokenType.GT, '>', self.line, col)
            
            if self.current_char == '<':
                col = self.column
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(TokenType.LE, '<=', self.line, col)
                return Token(TokenType.LT, '<', self.line, col)
            
            if self.current_char == '(':
                col = self.column
                self.advance()
                return Token(TokenType.LPAREN, '(', self.line, col)
            
            if self.current_char == ')':
                col = self.column
                self.advance()
                return Token(TokenType.RPAREN, ')', self.line, col)
            
            if self.current_char == ',':
                col = self.column
                self.advance()
                return Token(TokenType.COMMA, ',', self.line, col)
            
            if self.current_char == ';':
                col = self.column
                self.advance()
                return Token(TokenType.SEMICOLON, ';', self.line, col)
            
            if self.current_char == "'":
                return self.process_string()
            
            # Неизвестный символ
            token = Token(TokenType.ERROR, self.current_char, self.line, self.column)
            self.advance()
            return token
        
        # Конец файла
        return Token(TokenType.EOF, None, self.line, self.column)

# Узел дерева синтаксического разбора
class ParseTreeNode:
    def __init__(self, symbol, value=None):
        self.symbol = symbol  # Символ (терминал или нетерминал)
        self.value = value    # Значение для терминалов
        self.children = []    # Дочерние узлы
    
    def add_child(self, node):
        self.children.append(node)
    
    def __str__(self):
        if self.value:
            return f"{self.symbol}: {self.value}"
        return f"{self.symbol}"

# Грамматика для подмножества Fortran
class FortranGrammar:
    def __init__(self):
        # Нетерминалы
        self.non_terminals = {
            'program', 'declarations', 'declaration', 'type',
            'statements', 'statement', 'expression', 'expression_tail',
            'term', 'term_tail', 'factor', 'print_statement', 'print_tail',
            'id_list', 'id_list_tail', 'optional_init', 'assignment_statement',
            'var_decl_tail', 'if_statement', 'function_call', 'argument_list',
            'argument_list_tail', 'relational_expression', 'rel_op', 'simple_expression', 
            'optional_relational', 'mult_tail', 'id_or_init_list', 'id_or_init_list_tail', 'identifier_with_init'
        }
        # Терминалы (соответствуют TokenType)
        self.terminals = {
            TokenType.PROGRAM, TokenType.END, TokenType.INTEGER, TokenType.REAL, TokenType.LOGICAL,
            TokenType.IDENTIFIER, TokenType.INTEGER_CONST, TokenType.REAL_CONST, TokenType.STRING_CONST,
            TokenType.PLUS, TokenType.MINUS, TokenType.MULTIPLY, TokenType.DIVIDE,
            TokenType.ASSIGN, TokenType.LPAREN, TokenType.RPAREN, TokenType.IF, TokenType.THEN,
            TokenType.ELSE, TokenType.ENDIF, TokenType.NEWLINE, TokenType.EOF, TokenType.PRINT, 
            TokenType.COMMA, TokenType.COLON, TokenType.DOUBLE_COLON, TokenType.MOD,
            TokenType.EQ, TokenType.NE, TokenType.GT, TokenType.LT, TokenType.GE, TokenType.LE
        }

        
        # Продукции грамматики с левой факторизацией для устранения конфликтов
        self.productions = {
            'program': [
                [TokenType.PROGRAM, TokenType.IDENTIFIER, TokenType.NEWLINE, 
                'declarations', 'statements', TokenType.END, TokenType.PROGRAM]
            ],
            'declarations': [
                ['declaration', 'declarations'],
                []  # Epsilon-продукция
            ],
            'declaration': [
                ['type', 'var_decl_tail']
            ],
            'var_decl_tail': [
                [TokenType.DOUBLE_COLON, 'id_or_init_list', TokenType.NEWLINE],
                [TokenType.IDENTIFIER, 'optional_init', 'id_list_tail', TokenType.NEWLINE]
            ],
            'id_or_init_list': [
                ['identifier_with_init', 'id_or_init_list_tail']
            ],
            'id_or_init_list_tail': [
                [TokenType.COMMA, 'identifier_with_init', 'id_or_init_list_tail'],
                []  # Epsilon-продукция
            ],
            'identifier_with_init': [
                [TokenType.IDENTIFIER, 'optional_init']
            ],
            'optional_init': [
                [TokenType.ASSIGN, 'expression'],
                []  # Epsilon-продукция
            ],
            'type': [
                [TokenType.INTEGER],
                [TokenType.REAL],
                [TokenType.LOGICAL]
            ],
            'statements': [
                ['statement', 'statements'],
                []  # Epsilon-продукция
            ],
            'statement': [
                ['assignment_statement', TokenType.NEWLINE],
                ['print_statement', TokenType.NEWLINE],
                ['if_statement']
            ],
            'if_statement': [
                [TokenType.IF, TokenType.LPAREN, 'expression', TokenType.RPAREN, TokenType.THEN, TokenType.NEWLINE,
                'statements',
                TokenType.ELSE, TokenType.NEWLINE,
                'statements',
                TokenType.END, TokenType.IF, TokenType.NEWLINE]
            ],
            'assignment_statement': [
                [TokenType.IDENTIFIER, TokenType.ASSIGN, 'expression']
            ],
            # Левая факторизация для устранения конфликтов
            'expression': [
                ['simple_expression', 'optional_relational']
            ],
            'optional_relational': [
                ['rel_op', 'simple_expression'],
                []  # Epsilon-продукция
            ],
            'simple_expression': [
                ['term', 'expression_tail']
            ],
            'relational_expression': [
                ['term', 'rel_op', 'term']
            ],
            'rel_op': [
                [TokenType.EQ],
                [TokenType.NE],
                [TokenType.GT],
                [TokenType.LT],
                [TokenType.GE],
                [TokenType.LE]
            ],
            'expression_tail': [
                [TokenType.PLUS, 'term', 'expression_tail'],
                [TokenType.MINUS, 'term', 'expression_tail'],
                []  # Epsilon-продукция
            ],
            'term': [
                ['factor', 'term_tail']
            ],
            'term_tail': [
                [TokenType.MULTIPLY, 'factor', 'term_tail'],
                [TokenType.DIVIDE, 'factor', 'term_tail'],
                []  # Epsilon-продукция
            ],
            'factor': [
                [TokenType.LPAREN, 'expression', TokenType.RPAREN],
                ['function_call'],
                [TokenType.IDENTIFIER],
                [TokenType.INTEGER_CONST],
                [TokenType.REAL_CONST]
            ],
            'function_call': [
                [TokenType.MOD, TokenType.LPAREN, 'argument_list', TokenType.RPAREN]
            ],
            'argument_list': [
                ['expression', 'argument_list_tail'],
                []  # Пустой список аргументов
            ],
            'argument_list_tail': [
                [TokenType.COMMA, 'expression', 'argument_list_tail'],
                []  # Конец списка аргументов
            ],
            'print_statement': [
                [TokenType.PRINT, 'print_tail']
            ],
            'print_tail': [
                [TokenType.STRING_CONST],
                [TokenType.MULTIPLY, 'mult_tail']
            ],
            'mult_tail': [
                [TokenType.COMMA, 'expression'],
                []  # Epsilon для случая просто PRINT *
            ]
        }
        
        # Создаем LL(1) таблицу разбора
        self.parsing_table = self.build_parsing_table()


    
    def build_parsing_table(self):
        """Построение LL(1) таблицы разбора"""
        # Вычисление множеств FIRST и FOLLOW
        first_sets = self.compute_first_sets()
        follow_sets = self.compute_follow_sets(first_sets)
        
        # Инициализация таблицы разбора
        table = {}
        
        # Заполнение таблицы
        for non_terminal, productions in self.productions.items():
            for production in productions:
                if not production:  # Epsilon-продукция
                    for follow_symbol in follow_sets[non_terminal]:
                        if (non_terminal, follow_symbol) in table:
                            raise Exception(f"Grammar is not LL(1): Conflict at {non_terminal}, {follow_symbol}")
                        table[(non_terminal, follow_symbol)] = production
                else:
                    first_symbol = production[0]
                    if first_symbol in self.terminals:
                        if (non_terminal, first_symbol) in table:
                            raise Exception(f"Grammar is not LL(1): Conflict at {non_terminal}, {first_symbol}")
                        table[(non_terminal, first_symbol)] = production
                    else:  # Нетерминал
                        for terminal in first_sets[first_symbol]:
                            if terminal is None:  # Epsilon
                                for follow_symbol in follow_sets[non_terminal]:
                                    if (non_terminal, follow_symbol) in table:
                                        raise Exception(f"Grammar is not LL(1): Conflict at {non_terminal}, {follow_symbol}")
                                    table[(non_terminal, follow_symbol)] = production
                            else:
                                if (non_terminal, terminal) in table:
                                    raise Exception(f"Grammar is not LL(1): Conflict at {non_terminal}, {terminal}")
                                table[(non_terminal, terminal)] = production
        
        return table
    
    def compute_first_sets(self):
        """Вычисление множеств FIRST для всех символов грамматики"""
        first = {nt: set() for nt in self.non_terminals}
        for terminal in self.terminals:
            first[terminal] = {terminal}
        
        while True:
            changed = False
            
            for non_terminal, productions in self.productions.items():
                for production in productions:
                    if not production:  # Epsilon-продукция
                        if None not in first[non_terminal]:
                            first[non_terminal].add(None)
                            changed = True
                    else:
                        # Для первого символа в продукции
                        symbol = production[0]
                        for terminal in first[symbol]:
                            if terminal is not None and terminal not in first[non_terminal]:
                                first[non_terminal].add(terminal)
                                changed = True
                        
                        # Если все предыдущие символы могут быть epsilon
                        i = 0
                        while i < len(production) and None in first[production[i]]:
                            i += 1
                            if i < len(production):
                                symbol = production[i]
                                for terminal in first[symbol]:
                                    if terminal is not None and terminal not in first[non_terminal]:
                                        first[non_terminal].add(terminal)
                                        changed = True
            
            if not changed:
                break
        
        return first
    
    def compute_follow_sets(self, first_sets):
        """Вычисление множеств FOLLOW для всех нетерминалов"""
        follow = {nt: set() for nt in self.non_terminals}
        follow['program'].add(TokenType.EOF)  # EOF в FOLLOW для стартового символа
        
        while True:
            changed = False
            
            for non_terminal, productions in self.productions.items():
                for production in productions:
                    for i, symbol in enumerate(production):
                        if symbol in self.non_terminals:
                            # Правило 2: вычисляем FIRST для хвоста
                            if i + 1 < len(production):
                                next_symbol = production[i + 1]
                                for terminal in first_sets[next_symbol]:
                                    if terminal is None:  # Epsilon
                                        continue
                                    if terminal not in follow[symbol]:
                                        follow[symbol].add(terminal)
                                        changed = True
                            
                            # Правило 3: если следующий символ может быть epsilon или достигнут конец продукции
                            if (i + 1 == len(production) or 
                                all(None in first_sets[s] for s in production[i+1:])):
                                for terminal in follow[non_terminal]:
                                    if terminal not in follow[symbol]:
                                        follow[symbol].add(terminal)
                                        changed = True
            
            if not changed:
                break
        
        return follow

# Табличный LL(1) анализатор
class LLParser:
    def __init__(self, lexer, grammar):
        self.lexer = lexer
        self.grammar = grammar
        self.current_token = lexer.get_next_token()
        self.parse_tree = None
    
    def parse(self):
        """Запуск синтаксического анализа"""
        self.parse_tree = self._parse_non_terminal('program')
        return self.parse_tree
    
    def _parse_non_terminal(self, non_terminal):
        """Разбор нетерминала с построением дерева"""
        node = ParseTreeNode(non_terminal)
        
        # Определяем продукцию из таблицы разбора
        key = (non_terminal, self.current_token.type)
        if key not in self.grammar.parsing_table:
            return
            # raise Exception(f"Syntax error: unexpected token {self.current_token.type} for {non_terminal}")
        
        production = self.grammar.parsing_table[key]
        
        # Обрабатываем каждый символ в продукции
        for symbol in production:
            if symbol in self.grammar.terminals:
                # Терминал: проверяем соответствие
                # if self.current_token.type == symbol:
                    child = ParseTreeNode(str(symbol), self.current_token.value)
                    node.add_child(child)
                    self.current_token = self.lexer.get_next_token()
                # else:
                    # raise Exception(f"Syntax error: expected {symbol}, got {self.current_token.type}")
            elif symbol in self.grammar.non_terminals:
                # Нетерминал: рекурсивно разбираем
                child = self._parse_non_terminal(symbol)
                node.add_child(child)
        
        return node


def print_parse_tree(node, depth=0):
    """Отображение дерева разбора"""
    indent = "  " * depth
    print(f"{indent}{node}")
    for child in node.children:
        print_parse_tree(child, depth + 1)

def main():
    if len(sys.argv) != 2:
        print("Использование: python fortran_parser.py <имя_файла>")
        return
    
    try:
        with open(sys.argv[1], 'r') as file:
            text = file.read()
    except Exception as e:
        print(f"Ошибка при чтении файла: {e}")
        return
    
    # Лексический анализ
    lexer = Lexer(text)
    tokens = []
    token = lexer.get_next_token()
    
    print("Результаты лексического анализа:")
    while token.type != TokenType.EOF:
        print(token)
        tokens.append(token)
        token = lexer.get_next_token()
    
    # Сброс лексера для синтаксического анализа
    lexer = Lexer(text)
    
    # Синтаксический анализ
    grammar = FortranGrammar()
    parser = LLParser(lexer, grammar)
    
    try:
        parse_tree = parser.parse()
        print("\nДерево синтаксического разбора:")
        print_parse_tree(parse_tree)
    except Exception as e:
        print(f"Ошибка при синтаксическом анализе: {e}")

if __name__ == "__main__":
    main()
