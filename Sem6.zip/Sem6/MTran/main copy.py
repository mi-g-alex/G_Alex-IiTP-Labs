import re

class FortranLexer:
    def __init__(self):
        self.keywords = {
            'INTEGER', 'REAL', 'LOGICAL', 'CHARACTER', 'PARAMETER',
            'DIMENSION', 'SUBROUTINE', 'PROGRAM', 'IMPLICIT', 'NONE',
            'INTENT', 'IN', 'OUT', 'INOUT', 'IF', 'THEN', 'ELSE', 'END',
            'DO', 'CALL', 'PRINT', 'MOD', 'MODULE', 'CONTAINS', 'USE'
        }
        self.token_spec = [
            ('COMMENT', r'!.*'),
            ('STRING', r"'(''|[^'])*'"),
            ('LOGICAL_CONSTANT', r'\.(TRUE|FALSE)\.', re.IGNORECASE),
            ('REAL_CONSTANT', r'\d+\.\d*([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?|\d+[eE][+-]?\d+'),
            ('INTEGER_CONSTANT', r'\d+'),
            ('OPERATOR', r'(\.(AND|OR|NOT|EQ|NE|LT|LE|GT|GE)\.|==|/=|<=|>=|<|>|\+\+|--|\*\*|\+|-|\*|/|%|)'),
            ('DELIMITER', r'\(|\)|::|:|,|;|%|=|\n'),
            ('TYPE', r'\b(INTEGER|REAL|LOGICAL|CHARACTER)\b', re.IGNORECASE),
            ('KEYWORD', r'\b([A-Za-z][A-Za-z0-9_]*)\b', re.IGNORECASE),
            ('WHITESPACE', r'\s+'),
            ('ERROR', r'.'),
        ]
        self.token_regex = re.compile(
            '|'.join(f'(?P<{name}>{pattern})' for name, pattern, *flags in self.token_spec),
            flags=re.IGNORECASE | re.VERBOSE
        )

    def lex(self, code):
        variables = {}
        subroutines = set()
        constants = {}
        keywords = set()
        operators = set()
        delimiters = set()
        errors = []
        tokens = []
        
        declaration_stack = []
        current_type = None
        in_subroutine = False
        in_program = False

        for match in self.token_regex.finditer(code):
            token_type = match.lastgroup
            value = match.group().upper() if token_type in ['KEYWORD', 'TYPE'] else match.group()
            raw_value = match.group()
            start = match.start()
            end = match.end()

            if token_type == 'WHITESPACE':
                continue
            elif token_type == 'COMMENT':
                continue

            # Заполнение таблиц
            if token_type == 'KEYWORD' and value in self.keywords:
                keywords.add(value)
            elif token_type == 'OPERATOR':
                operators.add(raw_value)
            elif token_type == 'DELIMITER':
                delimiters.add(raw_value)
            elif token_type in ['INTEGER_CONSTANT', 'REAL_CONSTANT', 'LOGICAL_CONSTANT', 'STRING']:
                constants[raw_value] = token_type.split('_')[0]

            # Обработка объявлений
            if token_type == 'TYPE':
                current_type = value
                declaration_stack.append('type_decl')
            elif token_type == 'IDENTIFIER':
                if declaration_stack:
                    if declaration_stack[-1] == 'type_decl':
                        variables[raw_value] = current_type
                        declaration_stack.pop()
                    elif declaration_stack[-1] == 'subroutine':
                        subroutines.add(raw_value)
                        declaration_stack.pop()
                elif raw_value not in variables and raw_value not in subroutines and raw_value.upper() not in self.keywords:
                    errors.append(f"Undeclared identifier: {raw_value} at position {start}")

            # Обработка областей видимости
            if token_type == 'KEYWORD':
                if value == 'SUBROUTINE':
                    declaration_stack.append('subroutine')
                elif value == 'PROGRAM':
                    declaration_stack.append('program')
                elif value == 'END' and declaration_stack:
                    declaration_stack.pop()

            tokens.append((token_type, raw_value, start, end))

        return {
            'variables': variables,
            'subroutines': subroutines,
            'constants': constants,
            'keywords': keywords,
            'operators': operators,
            'delimiters': delimiters,
            'errors': errors,
            'tokens': tokens,
        }

def print_table(title, items, headers):
    print(f"\n{title}:")
    print(f"{headers[0]:<20} | {headers[1]}")
    print("-" * 30)
    for key, value in items.items():
        print(f"{key:<20} | {value}")

def print_set(title, items):
    print(f"\n{title}:")
    if items:
        print(", ".join(sorted(items)))
    else:
        print("None")

if __name__ == "__main__":
    code = """
subroutine check_even(n)
    implicit none
    integer, intent(in) :: n
    
    if (mod(n, 2) == 0) then
        print *, n, ' - even'
    else
        print *, n, ' - odd'
    end if
end subroutine check_even

program main
    implicit none
    integer :: numbers(5), i, n = 3, ans = 1
    
    do i = 1, 5
        numbers(i) = i
    end do
    
    do i = 1, 5
        call check_even(numbers(i))
    end do
    
    print *, ans
end program main
    """

    lexer = FortranLexer()
    result = lexer.lex(code)

    print_table("Variables", result['variables'], ["Name", "Type"])
    print_table("Constants", result['constants'], ["Value", "Type"])
    print_set("Subroutines", result['subroutines'])
    print_set("Keywords", result['keywords'])
    print_set("Operators", result['operators'])
    print_set("Delimiters", result['delimiters'])

    if result['errors']:
        print("\nErrors:")
        for error in result['errors']:
            print(f"- {error}")
    else:
        print("\nNo errors detected.")