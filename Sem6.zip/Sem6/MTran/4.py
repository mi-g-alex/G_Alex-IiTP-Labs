import re
import sys


# --- ЛЕКСИЧЕСКИЙ АНАЛИЗАТОР ---

class Token:
    def __init__(self, type, value, line, column):
        self.type = type
        self.value = value
        self.line = line
        self.column = column
    
    def __str__(self):
        return f"Token({self.type}, '{self.value}', line={self.line}, col={self.column})"
    
    def __repr__(self):
        return self.__str__()


class Lexer:
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.current_char = text[0] if text else None
        self.line = 1
        self.column = 1
    
    def error(self):
        raise Exception(f'Недопустимый символ: {self.current_char} на строке {self.line}, столбце {self.column}')
    
    def advance(self):
        """Перемещаем указатель на следующий символ"""
        if self.current_char == '\n':
            self.line += 1
            self.column = 0
        
        self.pos += 1
        self.column += 1
        
        if self.pos >= len(self.text):
            self.current_char = None
        else:
            self.current_char = self.text[self.pos]
    
    def skip_whitespace(self):
        while self.current_char is not None and self.current_char.isspace():
            self.advance()
    
    def skip_comment(self):
        while self.current_char is not None and self.current_char != '\n':
            self.advance()
    
    def number(self):
        """Обрабатывает целые и вещественные числа"""
        result = ''
        token_type = 'INTEGER'
        line = self.line
        column = self.column
        
        while self.current_char is not None and self.current_char.isdigit():
            result += self.current_char
            self.advance()
        
        if self.current_char == '.':
            token_type = 'REAL'
            result += self.current_char
            self.advance()
            
            while self.current_char is not None and self.current_char.isdigit():
                result += self.current_char
                self.advance()
        
        # Обработка экспоненциальной записи (1.23E+4)
        if self.current_char is not None and self.current_char.upper() == 'E':
            token_type = 'REAL'
            result += self.current_char
            self.advance()
            
            if self.current_char in ('+', '-'):
                result += self.current_char
                self.advance()
            
            while self.current_char is not None and self.current_char.isdigit():
                result += self.current_char
                self.advance()
        
        if token_type == 'INTEGER':
            return Token(token_type, int(result), line, column)
        else:
            return Token(token_type, float(result), line, column)
    
    def identifier(self):
        """Обрабатывает идентификаторы и ключевые слова"""
        result = ''
        line = self.line
        column = self.column
        
        while self.current_char is not None and (self.current_char.isalnum() or self.current_char == '_'):
            result += self.current_char
            self.advance()
        
        # Проверка на ключевые слова
        keywords = {
            'program': 'PROGRAM',
            'end': 'END',
            'if': 'IF',
            'then': 'THEN',
            'else': 'ELSE',
            'do': 'DO',
            'while': 'WHILE',
            'integer': 'INTEGER_TYPE',
            'real': 'REAL_TYPE',
            'logical': 'LOGICAL_TYPE',
            'character': 'CHARACTER_TYPE',
            'print': 'PRINT',
            'read': 'READ',
            'true': 'TRUE',
            'false': 'FALSE'
        }
        
        token_type = keywords.get(result.lower(), 'ID')
        
        return Token(token_type, result, line, column)
    
    def string(self):
        """Обрабатывает строковые литералы"""
        result = ''
        line = self.line
        column = self.column
        
        # Пропускаем начальную кавычку
        self.advance()
        
        while self.current_char is not None and self.current_char != "'":
            result += self.current_char
            self.advance()
        
        # Пропускаем конечную кавычку
        if self.current_char == "'":
            self.advance()
        else:
            raise Exception(f"Необработанная строка на строке {line}, столбце {column}")
        
        return Token('STRING', result, line, column)
    
    def logical_operator(self):
        """Обрабатывает логические операторы .AND., .OR., .NOT., и т.д."""
        result = '.'
        line = self.line
        column = self.column
        
        self.advance()  # пропускаем начальную точку
        
        while self.current_char is not None and self.current_char.isalpha():
            result += self.current_char
            self.advance()
        
        if self.current_char == '.':
            result += self.current_char
            self.advance()
        else:
            raise Exception(f"Незавершенный логический оператор {result} на строке {line}, столбце {column}")
        
        logical_operators = {
            '.AND.': 'AND',
            '.OR.': 'OR',
            '.NOT.': 'NOT',
            '.EQ.': 'EQ',
            '.NE.': 'NE',
            '.LT.': 'LT',
            '.LE.': 'LE',
            '.GT.': 'GT',
            '.GE.': 'GE',
            '.TRUE.': 'TRUE',
            '.FALSE.': 'FALSE'
        }
        
        token_type = logical_operators.get(result.upper())
        if token_type is None:
            raise Exception(f"Неизвестный логический оператор {result} на строке {line}, столбце {column}")
        
        return Token(token_type, result, line, column)
    
    def get_next_token(self):
        """Получение следующего токена"""
        while self.current_char is not None:
            
            if self.current_char.isspace():
                self.skip_whitespace()
                continue
            
            if self.current_char == '!' or (self.current_char == 'c' and self.column == 1):
                self.skip_comment()
                continue
            
            if self.current_char.isdigit():
                return self.number()
            
            if self.current_char.isalpha() or self.current_char == '_':
                return self.identifier()
            
            if self.current_char == "'":
                return self.string()
            
            if self.current_char == '.':
                # Проверяем, является ли это числом или логическим оператором
                next_pos = self.pos + 1
                if next_pos < len(self.text) and self.text[next_pos].isdigit():
                    return self.number()  # вещественное число начинается с точки
                else:
                    return self.logical_operator()
            
            if self.current_char == '=':
                token = Token('ASSIGN', '=', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == ':':
                line = self.line
                column = self.column
                self.advance()
                
                if self.current_char == ':':
                    self.advance()
                    return Token('DOUBLE_COLON', '::', line, column)
                
                return Token('COLON', ':', line, column)
            
            if self.current_char == ',':
                token = Token('COMMA', ',', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == '+':
                token = Token('PLUS', '+', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == '-':
                token = Token('MINUS', '-', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == '*':
                token = Token('STAR', '*', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == '/':
                token = Token('SLASH', '/', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == '(':
                token = Token('LPAREN', '(', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == ')':
                token = Token('RPAREN', ')', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == '[':
                token = Token('LBRACKET', '[', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == ']':
                token = Token('RBRACKET', ']', self.line, self.column)
                self.advance()
                return token
            
            if self.current_char == '<':
                line = self.line
                column = self.column
                self.advance()
                
                if self.current_char == '=':
                    self.advance()
                    return Token('LE', '<=', line, column)
                
                return Token('LT', '<', line, column)
            
            if self.current_char == '>':
                line = self.line
                column = self.column
                self.advance()
                
                if self.current_char == '=':
                    self.advance()
                    return Token('GE', '>=', line, column)
                
                return Token('GT', '>', line, column)
            
            if self.current_char == '=':
                line = self.line
                column = self.column
                self.advance()
                
                if self.current_char == '=':
                    self.advance()
                    return Token('EQ', '==', line, column)
                
                return Token('ASSIGN', '=', line, column)
            
            self.error()
        
        return Token('EOF', None, self.line, self.column)


# --- СИНТАКСИЧЕСКИЙ АНАЛИЗАТОР ---

class Parser:
    def __init__(self, lexer):
        self.lexer = lexer
        self.current_token = self.lexer.get_next_token()
    
    def error(self, expected_type=None):
        msg = f'Синтаксическая ошибка на строке {self.current_token.line}, столбце {self.current_token.column}'
        if expected_type:
            msg += f': ожидался {expected_type}, получен {self.current_token.type}'
        raise Exception(msg)
    
    def eat(self, token_type):
        """
        Сравниваем текущий токен с ожидаемым типом токена.
        Если типы совпадают, 'съедаем' текущий токен и переходим к следующему.
        Иначе - ошибка.
        """
        if self.current_token.type == token_type:
            value = self.current_token.value
            self.current_token = self.lexer.get_next_token()
            return value
        else:
            self.error(token_type)
    
    def program(self):
        """
        program : PROGRAM ID declaration_list statement_list END PROGRAM ID
        """
        self.eat('PROGRAM')
        program_name = self.eat('ID')
        
        declarations = []
        while self.current_token.type in ('INTEGER_TYPE', 'REAL_TYPE', 'LOGICAL_TYPE', 'CHARACTER_TYPE'):
            declarations.append(self.declaration())
        
        statements = []
        while self.current_token.type not in ('END', 'EOF'):
            statements.append(self.statement())
        
        self.eat('END')
        self.eat('PROGRAM')
        
        # Программа может закончиться именем или просто END PROGRAM
        if self.current_token.type == 'ID':
            end_name = self.eat('ID')
            if end_name != program_name:
                print(f"Предупреждение: имя в END PROGRAM {end_name} не совпадает с именем программы {program_name}")
        
        return {
            'type': 'program',
            'name': program_name,
            'declarations': declarations,
            'statements': statements
        }
    
    def declaration(self):
        """
        declaration : type [DOUBLE_COLON] variable_list
        type : INTEGER_TYPE | REAL_TYPE | LOGICAL_TYPE | CHARACTER_TYPE
        """
        if self.current_token.type == 'INTEGER_TYPE':
            type_name = 'INTEGER'
            self.eat('INTEGER_TYPE')
        elif self.current_token.type == 'REAL_TYPE':
            type_name = 'REAL'
            self.eat('REAL_TYPE')
        elif self.current_token.type == 'LOGICAL_TYPE':
            type_name = 'LOGICAL'
            self.eat('LOGICAL_TYPE')
        elif self.current_token.type == 'CHARACTER_TYPE':
            type_name = 'CHARACTER'
            self.eat('CHARACTER_TYPE')
        else:
            self.error()
        
        # Двойное двоеточие в Fortran 90+ синтаксисе (необязательно)
        if self.current_token.type == 'DOUBLE_COLON':
            self.eat('DOUBLE_COLON')
        
        variables = self.variable_list()
        
        return {
            'type': 'declaration',
            'data_type': type_name,
            'variables': variables
        }
    
    def variable_list(self):
        """
        variable_list : variable_declaration (COMMA variable_declaration)*
        """
        variables = []
        
        var = self.variable_declaration()
        variables.append(var)
        
        while self.current_token.type == 'COMMA':
            self.eat('COMMA')
            var = self.variable_declaration()
            variables.append(var)
        
        return variables
    
    def variable_declaration(self):
        """
        variable_declaration : ID [dimensions] [ASSIGN expr]
        """
        name = self.eat('ID')
        
        # Проверяем, является ли это объявлением массива
        if self.current_token.type == 'LPAREN':
            dimensions = self.dimensions()
            var = {
                'type': 'array',
                'name': name,
                'dimensions': dimensions
            }
        else:
            var = name
        
        # Проверяем, есть ли инициализация
        if self.current_token.type == 'ASSIGN' or self.current_token.type == '=':
            self.eat(self.current_token.type)  # ASSIGN or =
            if isinstance(var, dict) and var['type'] == 'array':
                # Инициализация массива (не обрабатывается пока)
                var['init_value'] = self.array_initializer()
            else:
                # Инициализация скаляра
                var = {
                    'type': 'initialized_variable',
                    'name': name,
                    'value': self.expr()
                }
        
        return var
    
    def dimensions(self):
        """
        dimensions : LPAREN dimension (COMMA dimension)* RPAREN
        dimension : [expr COLON] expr
        """
        self.eat('LPAREN')
        
        dimensions = []
        
        # Обрабатываем первое измерение
        if self.current_token.type != 'RPAREN':
            dimensions.append(self.dimension())
            
            while self.current_token.type == 'COMMA':
                self.eat('COMMA')
                dimensions.append(self.dimension())
        
        self.eat('RPAREN')
        
        return dimensions
    
    def dimension(self):
        """
        dimension : [expr COLON] expr
        """
        lower_bound = 1  # По умолчанию в Fortran
        upper_bound = self.expr()
        
        if self.current_token.type == 'COLON':
            self.eat('COLON')
            lower_bound = upper_bound
            upper_bound = self.expr()
        
        return (lower_bound, upper_bound)
    
    def array_initializer(self):
        """
        array_initializer : expr | (/ expr_list /) | [expr_list]
        """
        if self.current_token.type == 'LPAREN' and self.lexer.current_char == '/':
            # Fortran 90 формат: (/ 1, 2, 3 /)
            self.eat('LPAREN')
            self.lexer.advance()  # Пропускаем /
            
            values = self.expr_list()
            
            if self.current_token.type == 'SLASH':
                self.eat('SLASH')
            self.eat('RPAREN')
            
            return values
        elif self.current_token.type == 'LBRACKET':
            # Fortran 2003+ формат: [1, 2, 3]
            self.eat('LBRACKET')
            
            values = self.expr_list()
            
            self.eat('RBRACKET')
            
            return values
        else:
            # Простой случай: одно значение или выражение
            return self.expr()
    
    def expr_list(self):
        """
        expr_list : expr (COMMA expr)*
        """
        expressions = [self.expr()]
        
        while self.current_token.type == 'COMMA':
            self.eat('COMMA')
            expressions.append(self.expr())
        
        return expressions
    
    def statement(self):
        """
        statement : assignment | if_statement | do_loop | print_statement | ...
        """
        if self.current_token.type == 'ID':
            return self.assignment()
        elif self.current_token.type == 'IF':
            return self.if_statement()
        elif self.current_token.type == 'DO':
            return self.do_loop()
        elif self.current_token.type == 'PRINT':
            return self.print_statement()
        elif self.current_token.type == 'READ':
            return self.read_statement()
        else:
            self.error()
    
    def assignment(self):
        """
        assignment : variable ASSIGN expr
        """
        var = self.variable()
        
        self.eat('ASSIGN')
        
        value = self.expr()
        
        return {
            'type': 'assignment',
            'target': var,
            'value': value
        }
    
    def variable(self):
        """
        variable : ID [LPAREN expr_list RPAREN]
        """
        name = self.eat('ID')
        
        if self.current_token.type == 'LPAREN':
            self.eat('LPAREN')
            indices = self.expr_list()
            self.eat('RPAREN')
            
            return {
                'type': 'array_element',
                'name': name,
                'indices': indices
            }
        
        return name
    
    def if_statement(self):
        """
        if_statement : IF LPAREN expr RPAREN THEN statement_list [ELSE statement_list] END IF
        """
        self.eat('IF')
        self.eat('LPAREN')
        condition = self.expr()
        self.eat('RPAREN')
        self.eat('THEN')
        
        # Блок THEN
        then_block = []
        while self.current_token.type not in ('ELSE', 'END'):
            then_block.append(self.statement())
        
        # Блок ELSE (если есть)
        else_block = []
        if self.current_token.type == 'ELSE':
            self.eat('ELSE')
            while self.current_token.type != 'END':
                else_block.append(self.statement())
        
        self.eat('END')
        self.eat('IF')
        
        return {
            'type': 'if_statement',
            'condition': condition,
            'then_block': then_block,
            'else_block': else_block
        }
    
    def do_loop(self):
        """
        do_loop : DO [variable ASSIGN expr COMMA expr [COMMA expr]] statement_list END DO
        """
        self.eat('DO')
        
        # Проверяем, имеет ли цикл параметр управления
        if self.current_token.type == 'ID' and self.lexer.pos < len(self.lexer.text) and self.lexer.text[self.lexer.pos+1] == '=':
            loop_var = self.eat('ID')
            self.eat('ASSIGN')
            init_expr = self.expr()
            self.eat('COMMA')
            end_expr = self.expr()
            
            # Шаг цикла (необязательно)
            step_expr = 1
            if self.current_token.type == 'COMMA':
                self.eat('COMMA')
                step_expr = self.expr()
            
            # Тело цикла
            body = []
            while self.current_token.type != 'END':
                body.append(self.statement())
            
            self.eat('END')
            self.eat('DO')
            
            return {
                'type': 'do_loop',
                'loop_var': loop_var,
                'init_expr': init_expr,
                'end_expr': end_expr,
                'step_expr': step_expr,
                'body': body
            }
        else:
            # DO без параметров (DO WHILE или бесконечный цикл)
            condition = True
            if self.current_token.type == 'WHILE':
                self.eat('WHILE')
                self.eat('LPAREN')
                condition = self.expr()
                self.eat('RPAREN')
            
            # Тело цикла
            body = []
            while self.current_token.type != 'END':
                body.append(self.statement())
            
            self.eat('END')
            self.eat('DO')
            
            return {
                'type': 'while_loop',
                'condition': condition,
                'body': body
            }
    
    def print_statement(self):
        """
        print_statement : PRINT format [COMMA expr_list]
        format : STAR | INTEGER | expr
        """
        self.eat('PRINT')
        
        # Формат вывода
        format_spec = None
        if self.current_token.type == 'STAR':
            format_spec = '*'
            self.eat('STAR')
        elif self.current_token.type == 'INTEGER':
            format_spec = self.eat('INTEGER')
        else:
            format_spec = self.expr()
        
        # Список выражений для печати
        expressions = []
        if self.current_token.type == 'COMMA':
            self.eat('COMMA')
            expressions = self.expr_list()
        
        return {
            'type': 'print',
            'format': format_spec,
            'expressions': expressions
        }
    
    def read_statement(self):
        """
        read_statement : READ format [COMMA] variable_list
        """
        self.eat('READ')
        
        # Формат ввода
        format_spec = None
        if self.current_token.type == 'STAR':
            format_spec = '*'
            self.eat('STAR')
        elif self.current_token.type == 'INTEGER':
            format_spec = self.eat('INTEGER')
        else:
            format_spec = self.expr()
        
        # Список переменных для чтения
        variables = []
        if self.current_token.type == 'COMMA':
            self.eat('COMMA')
        
        variables = []
        var = self.variable()
        variables.append(var)
        
        while self.current_token.type == 'COMMA':
            self.eat('COMMA')
            var = self.variable()
            variables.append(var)
        
        return {
            'type': 'read',
            'format': format_spec,
            'variables': variables
        }
    
    def expr(self):
        """
        expr : and_expr ((OR | .OR.) and_expr)*
        """
        node = self.and_expr()
        
        while self.current_token.type in ('OR'):
            op = self.current_token.type
            self.eat(op)
            right = self.and_expr()
            
            node = {
                'op': '.OR.',
                'left': node,
                'right': right
            }
        
        return node
    
    def and_expr(self):
        """
        and_expr : not_expr ((AND | .AND.) not_expr)*
        """
        node = self.not_expr()
        
        while self.current_token.type in ('AND'):
            op = self.current_token.type
            self.eat(op)
            right = self.not_expr()
            
            node = {
                'op': '.AND.',
                'left': node,
                'right': right
            }
        
        return node
    
    def not_expr(self):
        """
        not_expr : (NOT | .NOT.)* comparison
        """
        if self.current_token.type in ('NOT'):
            op = self.current_token.type
            self.eat(op)
            operand = self.not_expr()
            
            return {
                'op': '.NOT.',
                'operand': operand
            }
        
        return self.comparison()
    
    def comparison(self):
        """
        comparison : arithmetic_expr ((EQ | NE | LT | LE | GT | GE | == | /= | < | <= | > | >=) arithmetic_expr)*
        """
        node = self.arithmetic_expr()
        
        while self.current_token.type in ('EQ', 'NE', 'LT', 'LE', 'GT', 'GE'):
            op = self.current_token.type
            self.eat(op)
            right = self.arithmetic_expr()
            
            op_map = {
                'EQ': '==',
                'NE': '/=',
                'LT': '<',
                'LE': '<=',
                'GT': '>',
                'GE': '>='
            }
            
            node = {
                'op': op_map[op],
                'left': node,
                'right': right
            }
        
        return node
    
    def arithmetic_expr(self):
        """
        arithmetic_expr : term ((PLUS | MINUS) term)*
        """
        node = self.term()
        
        while self.current_token.type in ('PLUS', 'MINUS'):
            op = self.current_token.type
            self.eat(op)
            right = self.term()
            
            op_map = {
                'PLUS': '+',
                'MINUS': '-'
            }
            
            node = {
                'op': op_map[op],
                'left': node,
                'right': right
            }
        
        return node
    
    def term(self):
        """
        term : factor ((STAR | SLASH) factor)*
        """
        node = self.factor()
        
        while self.current_token.type in ('STAR', 'SLASH'):
            op = self.current_token.type
            self.eat(op)
            right = self.factor()
            
            op_map = {
                'STAR': '*',
                'SLASH': '/'
            }
            
            node = {
                'op': op_map[op],
                'left': node,
                'right': right
            }
        
        return node
    
    def factor(self):
        """
        factor : PLUS factor
              | MINUS factor
              | INTEGER
              | REAL
              | TRUE
              | FALSE
              | STRING
              | variable
              | LPAREN expr RPAREN
        """
        token = self.current_token
        
        if token.type == 'PLUS':
            self.eat('PLUS')
            return {
                'op': '+',
                'operand': self.factor()
            }
        elif token.type == 'MINUS':
            self.eat('MINUS')
            return {
                'op': '-',
                'operand': self.factor()
            }
        elif token.type == 'INTEGER':
            return self.eat('INTEGER')
        elif token.type == 'REAL':
            return self.eat('REAL')
        elif token.type == 'TRUE':
            self.eat('TRUE')
            return True
        elif token.type == 'FALSE':
            self.eat('FALSE')
            return False
        elif token.type == 'STRING':
            return self.eat('STRING')
        elif token.type == 'ID':
            return self.variable()
        elif token.type == 'LPAREN':
            self.eat('LPAREN')
            node = self.expr()
            self.eat('RPAREN')
            return node
        else:
            self.error()
    
    def parse(self):
        """
        Запускает парсинг программы
        """
        ast = self.program()
        if self.current_token.type != 'EOF':
            self.error('EOF')
        return ast


# --- СЕМАНТИЧЕСКИЙ АНАЛИЗАТОР ---

class SymbolTable:
    """Таблица символов для хранения информации о переменных и их типах."""
    
    def __init__(self):
        self.symbols = {}
    
    def add_symbol(self, name, type_info, dimensions=None, value=None):
        """
        Добавление символа в таблицу.
        
        Args:
            name: Имя переменной
            type_info: Тип переменной (INTEGER, REAL, LOGICAL и т.д.)
            dimensions: Размерности массива (если это массив)
            value: Начальное значение (если есть)
        """
        self.symbols[name] = {
            'type': type_info,
            'dimensions': dimensions,
            'value': value
        }
    
    def lookup(self, name):
        """Поиск символа в таблице."""
        return self.symbols.get(name)
    
    def __str__(self):
        return str(self.symbols)


class SemanticAnalyzer:
    """Семантический анализатор для Fortran."""
    
    def __init__(self):
        self.symbol_table = SymbolTable()
    
    def analyze(self, ast):
        """
        Анализ абстрактного синтаксического дерева.
        
        Args:
            ast: Абстрактное синтаксическое дерево программы
            
        Returns:
            Проверенное AST с дополнительной семантической информацией
        """
        if ast['type'] == 'program':
            self.analyze_program(ast)
        return ast
    
    def analyze_program(self, program_node):
        """
        Анализ программы.
        
        Args:
            program_node: Узел AST, представляющий программу
        """
        # Обработка объявлений
        for decl in program_node.get('declarations', []):
            self.analyze_declaration(decl)
        
        # Обработка операторов
        for stmt in program_node.get('statements', []):
            self.analyze_statement(stmt)
    
    def analyze_declaration(self, decl_node):
        """
        Анализ объявления переменных.
        
        Args:
            decl_node: Узел AST, представляющий объявление
        """
        var_type = decl_node['data_type']
        
        for var in decl_node['variables']:
            if isinstance(var, dict):
                if var['type'] == 'array':
                    # Массив
                    name = var['name']
                    dimensions = var['dimensions']
                    
                    # Проверка, не была ли переменная уже объявлена
                    if self.symbol_table.lookup(name):
                        print(f"Предупреждение: повторное объявление {name}")
                    
                    self.symbol_table.add_symbol(name, var_type, dimensions)
                elif var['type'] == 'initialized_variable':
                    # Инициализированная переменная
                    name = var['name']
                    value = var['value']
                    
                    # Проверка, не была ли переменная уже объявлена
                    if self.symbol_table.lookup(name):
                        print(f"Предупреждение: повторное объявление {name}")
                    
                    # Проверка совместимости типа и значения
                    value = self.convert_value_to_type(value, var_type)
                    
                    self.symbol_table.add_symbol(name, var_type, None, value)
            else:
                # Обычная переменная
                name = var
                
                # Проверка, не была ли переменная уже объявлена
                if self.symbol_table.lookup(name):
                    print(f"Предупреждение: повторное объявление {name}")
                
                self.symbol_table.add_symbol(name, var_type)
    
    def analyze_statement(self, stmt_node):
        """
        Анализ оператора.
        
        Args:
            stmt_node: Узел AST, представляющий оператор
        """
        if stmt_node['type'] == 'assignment':
            self.analyze_assignment(stmt_node)
        elif stmt_node['type'] == 'if_statement':
            self.analyze_if_statement(stmt_node)
        elif stmt_node['type'] == 'do_loop' or stmt_node['type'] == 'while_loop':
            self.analyze_loop(stmt_node)
        elif stmt_node['type'] == 'print':
            self.analyze_print(stmt_node)
        elif stmt_node['type'] == 'read':
            self.analyze_read(stmt_node)
        # Добавьте другие типы операторов по мере необходимости
    
    def analyze_assignment(self, assign_node):
        """
        Анализ оператора присваивания.
        
        Args:
            assign_node: Узел AST, представляющий оператор присваивания
        """
        target = assign_node['target']
        value = assign_node['value']
        
        # Получение информации о целевой переменной
        if isinstance(target, dict) and target['type'] == 'array_element':
            # Элемент массива
            array_name = target['name']
            array_info = self.symbol_table.lookup(array_name)
            
            if not array_info:
                raise Exception(f"Неопределенная переменная: {array_name}")
            
            if not array_info['dimensions']:
                raise Exception(f"{array_name} не является массивом")
            
            # Проверка индексов
            indices = target['indices']
            if len(indices) != len(array_info['dimensions']):
                raise Exception(f"Неверное количество индексов для массива {array_name}")
            
            target_type = array_info['type']
        else:
            # Скалярная переменная
            var_name = target
            var_info = self.symbol_table.lookup(var_name)
            
            if not var_info:
                raise Exception(f"Неопределенная переменная: {var_name}")
            
            target_type = var_info['type']
        
        # Проверка совместимости типов и преобразование значения при необходимости
        value = self.convert_value_to_type(value, target_type)
        assign_node['value'] = value
    
    def analyze_if_statement(self, if_node):
        """
        Анализ условного оператора.
        
        Args:
            if_node: Узел AST, представляющий условный оператор
        """
        # Проверка условия
        condition = if_node['condition']
        self.check_boolean_expression(condition)
        
        # Анализ блоков then и else
        for stmt in if_node.get('then_block', []):
            self.analyze_statement(stmt)
        
        for stmt in if_node.get('else_block', []):
            self.analyze_statement(stmt)
    
    def analyze_loop(self, loop_node):
        """
        Анализ циклического оператора.
        
        Args:
            loop_node: Узел AST, представляющий циклический оператор
        """
        if loop_node['type'] == 'do_loop':
            # Цикл DO
            loop_var = loop_node['loop_var']
            var_info = self.symbol_table.lookup(loop_var)
            
            if not var_info:
                raise Exception(f"Неопределенная переменная цикла: {loop_var}")
            
            if var_info['type'] != 'INTEGER':
                raise Exception(f"Переменная цикла должна быть целочисленной: {loop_var}")
            
            # Проверка выражений начала, конца и шага
            init_expr = loop_node['init_expr']
            end_expr = loop_node['end_expr']
            step_expr = loop_node['step_expr']
            
            # Преобразование выражений к целочисленному типу
            loop_node['init_expr'] = self.convert_value_to_type(init_expr, 'INTEGER')
            loop_node['end_expr'] = self.convert_value_to_type(end_expr, 'INTEGER')
            loop_node['step_expr'] = self.convert_value_to_type(step_expr, 'INTEGER')
        
        elif loop_node['type'] == 'while_loop':
            # Цикл WHILE
            condition = loop_node['condition']
            self.check_boolean_expression(condition)
        
        # Анализ тела цикла
        for stmt in loop_node.get('body', []):
            self.analyze_statement(stmt)
    
    def analyze_print(self, print_node):
        """
        Анализ оператора печати.
        
        Args:
            print_node: Узел AST, представляющий оператор печати
        """
        # Проверка формата (если задан)
        format_spec = print_node.get('format')
        
        # Просто проверяем, что выражения доступны
        for expr in print_node.get('expressions', []):
            if isinstance(expr, str) and not expr.startswith("'") and not expr.endswith("'"):
                var_info = self.symbol_table.lookup(expr)
                if not var_info:
                    raise Exception(f"Неопределенная переменная: {expr}")
    
    def analyze_read(self, read_node):
        """
        Анализ оператора чтения.
        
        Args:
            read_node: Узел AST, представляющий оператор чтения
        """
        # Проверка формата (если задан)
        format_spec = read_node.get('format')
        
        # Проверка переменных для чтения
        for var in read_node.get('variables', []):
            if isinstance(var, dict) and var['type'] == 'array_element':
                # Элемент массива
                array_name = var['name']
                array_info = self.symbol_table.lookup(array_name)
                
                if not array_info:
                    raise Exception(f"Неопределенная переменная: {array_name}")
                
                if not array_info['dimensions']:
                    raise Exception(f"{array_name} не является массивом")
                
                # Проверка индексов
                indices = var['indices']
                if len(indices) != len(array_info['dimensions']):
                    raise Exception(f"Неверное количество индексов для массива {array_name}")
            else:
                # Скалярная переменная
                var_name = var
                var_info = self.symbol_table.lookup(var_name)
                
                if not var_info:
                    raise Exception(f"Неопределенная переменная: {var_name}")
    
    def check_boolean_expression(self, expr):
        """
        Проверка, что выражение является логическим.
        
        Args:
            expr: Проверяемое выражение
        """
        # Если expr - это словарь с операцией
        if isinstance(expr, dict) and 'op' in expr:
            op = expr['op']
            
            # Операции сравнения
            if op in ('==', '/=', '<', '<=', '>', '>='):
                # Все в порядке, они возвращают логическое значение
                return
            
            # Логические операции
            if op in ('.AND.', '.OR.', '.NOT.'):
                # Проверка операндов
                if 'left' in expr and 'right' in expr:
                    self.check_boolean_expression(expr['left'])
                    self.check_boolean_expression(expr['right'])
                elif 'operand' in expr:
                    self.check_boolean_expression(expr['operand'])
                return
        
        # Если expr - это логическая константа
        if expr is True or expr is False:
            return
        
        # Если expr - это переменная
        if isinstance(expr, str) and not expr.startswith("'") and not expr.endswith("'"):
            var_info = self.symbol_table.lookup(expr)
            if var_info and var_info['type'] == 'LOGICAL':
                return
        
        # В остальных случаях ожидаем, что выражение будет логическим
        # Здесь можно добавить дополнительные проверки или преобразования
    
    def convert_value_to_type(self, value, target_type):
        """
        Преобразует значение к указанному типу.
        
        Args:
            value: Значение для преобразования
            target_type: Целевой тип (INTEGER, REAL, LOGICAL, CHARACTER)
            
        Returns:
            Преобразованное значение
        """
        # Простой случай - значение уже правильного типа
        if value is True or value is False:
            if target_type == 'LOGICAL':
                return value
            elif target_type == 'INTEGER':
                return 1 if value else 0
            elif target_type == 'REAL':
                return 1.0 if value else 0.0
            else:
                raise Exception(f"Невозможно преобразовать логическое значение к типу {target_type}")
        
        # Числовые литералы
        if isinstance(value, (int, float)):
            if target_type == 'INTEGER':
                return int(value)
            elif target_type == 'REAL':
                return float(value)
            elif target_type == 'LOGICAL':
                return bool(value)
            else:
                raise Exception(f"Невозможно преобразовать числовое значение к типу {target_type}")
        
        # Строковые литералы
        if isinstance(value, str) and value.startswith("'") and value.endswith("'"):
            if target_type == 'CHARACTER':
                return value[1:-1]  # Убираем кавычки
            else:
                raise Exception(f"Невозможно преобразовать строковое значение к типу {target_type}")
        
        # Переменные
        if isinstance(value, str) and not value.startswith("'") and not value.endswith("'"):
            var_info = self.symbol_table.lookup(value)
            
            if not var_info:
                raise Exception(f"Неопределенная переменная: {value}")
            
            var_type = var_info['type']
            
            # Проверка совместимости типов
            if var_type == target_type:
                return value  # Типы совпадают
            
            # Проверка возможности преобразования
            if (var_type == 'INTEGER' and target_type == 'REAL') or \
               (var_type == 'REAL' and target_type == 'INTEGER') or \
               (var_type == 'INTEGER' and target_type == 'LOGICAL') or \
               (var_type == 'LOGICAL' and target_type == 'INTEGER'):
                return value  # Преобразование будет выполнено при выполнении
            
            raise Exception(f"Несовместимые типы: {var_type} и {target_type}")
        
        # Выражения
        if isinstance(value, dict) and 'op' in value:
            # Для сложных выражений просто возвращаем их без изменений
            # Фактическое преобразование типа будет выполнено при интерпретации
            return value
        
        # Если ничего не подошло, возвращаем значение как есть
        return value

# --- ИНТЕРПРЕТАТОР ---

class FortranInterpreter:
    def __init__(self):
        # Глобальное окружение для хранения переменных и их значений
        self.environment = {}
        # Стек для отслеживания вложенных вызовов
        self.call_stack = []
    
    def interpret(self, ast):
        """
        Интерпретирует абстрактное синтаксическое дерево программы.
        
        Args:
            ast: Абстрактное синтаксическое дерево программы
        """
        if ast['type'] == 'program':
            self.interpret_program(ast)
    
    def interpret_program(self, program_node):
        """
        Интерпретирует программу.
        
        Args:
            program_node: Узел AST, представляющий программу
        """
        # Инициализация переменных из объявлений
        for decl in program_node.get('declarations', []):
            self.interpret_declaration(decl)
        
        # Выполнение операторов
        for stmt in program_node.get('statements', []):
            self.interpret_statement(stmt)
    
    def interpret_declaration(self, decl_node):
        """
        Интерпретирует объявление переменных.
        
        Args:
            decl_node: Узел AST, представляющий объявление
        """
        var_type = decl_node['data_type']
        
        for var in decl_node['variables']:
            if isinstance(var, dict):
                if var['type'] == 'array':
                    # Инициализация массива
                    name = var['name']
                    dimensions = var['dimensions']
                    
                    # Создание многомерного массива с начальными значениями
                    array_data = self.create_array(var_type, dimensions)
                    
                    self.environment[name] = {
                        'type': var_type,
                        'dimensions': dimensions,
                        'data': array_data
                    }
                elif var['type'] == 'initialized_variable':
                    # Инициализированная переменная
                    name = var['name']
                    value = var['value']
                    
                    # Вычисление начального значения
                    init_value = self.evaluate_expression(value)
                    
                    # Преобразование к правильному типу
                    init_value = self.convert_to_type(init_value, var_type)
                    
                    self.environment[name] = init_value
            else:
                # Обычная переменная
                name = var
                
                # Установка начального значения по умолчанию
                if var_type == 'INTEGER':
                    self.environment[name] = 0
                elif var_type == 'REAL':
                    self.environment[name] = 0.0
                elif var_type == 'LOGICAL':
                    self.environment[name] = False
                elif var_type == 'CHARACTER':
                    self.environment[name] = ''
    
    def create_array(self, var_type, dimensions):
        """
        Создает многомерный массив с начальными значениями.
        
        Args:
            var_type: Тип элементов массива
            dimensions: Список кортежей с размерностями массива
            
        Returns:
            Многомерный массив (вложенные списки)
        """
        if not dimensions:
            # Выбор начального значения по типу
            if var_type == 'INTEGER':
                return 0
            elif var_type == 'REAL':
                return 0.0
            elif var_type == 'LOGICAL':
                return False
            elif var_type == 'CHARACTER':
                return ''
            else:
                return None
        
        # Рекурсивное создание массива
        start, end = dimensions[0]
        size = end - start + 1
        return [self.create_array(var_type, dimensions[1:]) for _ in range(size)]
    
    def interpret_statement(self, stmt_node):
        """
        Интерпретирует оператор.
        
        Args:
            stmt_node: Узел AST, представляющий оператор
        """
        if stmt_node['type'] == 'assignment':
            self.interpret_assignment(stmt_node)
        elif stmt_node['type'] == 'if_statement':
            self.interpret_if_statement(stmt_node)
        elif stmt_node['type'] == 'do_loop':
            self.interpret_do_loop(stmt_node)
        elif stmt_node['type'] == 'while_loop':
            self.interpret_while_loop(stmt_node)
        elif stmt_node['type'] == 'print':
            self.interpret_print(stmt_node)
        elif stmt_node['type'] == 'read':
            self.interpret_read(stmt_node)
        # Добавьте другие типы операторов по мере необходимости
    
    def interpret_assignment(self, assign_node):
        """
        Интерпретирует оператор присваивания.
        
        Args:
            assign_node: Узел AST, представляющий оператор присваивания
        """
        target = assign_node['target']
        value_expr = assign_node['value']
        
        # Вычисляем значение выражения
        value = self.evaluate_expression(value_expr)
        
        # Присваиваем значение целевой переменной
        if isinstance(target, dict) and target['type'] == 'array_element':
            # Присваивание элементу массива
            array_name = target['name']
            indices = [self.evaluate_expression(idx) for idx in target['indices']]
            
            self.set_array_element(array_name, indices, value)
        else:
            # Присваивание скалярной переменной
            self.environment[target] = value
    
    def interpret_if_statement(self, if_node):
        """
        Интерпретирует условный оператор.
        
        Args:
            if_node: Узел AST, представляющий условный оператор
        """
        condition = self.evaluate_expression(if_node['condition'])
        
        if condition:
            # Выполняем блок THEN
            for stmt in if_node.get('then_block', []):
                self.interpret_statement(stmt)
        else:
            # Выполняем блок ELSE, если он есть
            for stmt in if_node.get('else_block', []):
                self.interpret_statement(stmt)
    
    def interpret_print(self, print_node):
        """
        Интерпретирует оператор печати.
        
        Args:
            print_node: Узел AST, представляющий оператор печати
        """
        format_spec = print_node.get('format')
        expressions = print_node.get('expressions', [])
        
        # Вычисляем значения выражений
        values = []
        for expr in expressions:
            # Проверяем, является ли выражение строковым литералом
            if isinstance(expr, str) and expr.startswith("'") and expr.endswith("'"):
                # Строковой литерал - просто добавляем строку без кавычек
                values.append(expr[1:-1])
            else:
                # Другой тип выражения - вычисляем
                values.append(self.evaluate_expression(expr))
        
        # Простая реализация вывода
        if format_spec == '*':
            print(*values)
        else:
            # В реальном Fortran здесь должна быть обработка форматирования
            print(*values)
    
    def evaluate_expression(self, expr):
        """
        Вычисляет значение выражения.
        
        Args:
            expr: Выражение (может быть литералом, переменной, бинарной операцией и т.д.)
            
        Returns:
            Вычисленное значение выражения
        """
        # Если выражение является словарем, это бинарная или унарная операция
        if isinstance(expr, dict):
            if 'op' in expr and 'left' in expr and 'right' in expr:
                # Бинарная операция
                left_value = self.evaluate_expression(expr['left'])
                right_value = self.evaluate_expression(expr['right'])
                
                # Выполнение операции
                return self.perform_binary_operation(expr['op'], left_value, right_value)
            
            elif 'op' in expr and 'operand' in expr:
                # Унарная операция
                operand_value = self.evaluate_expression(expr['operand'])
                
                # Выполнение операции
                if expr['op'] == '+':
                    return operand_value
                elif expr['op'] == '-':
                    return -operand_value
                elif expr['op'] == '.NOT.':
                    return not operand_value
            
            elif expr.get('type') == 'array_element':
                # Доступ к элементу массива
                array_name = expr['name']
                indices = [self.evaluate_expression(idx) for idx in expr['indices']]
                
                return self.get_array_element(array_name, indices)
        
        # Обработка разных типов выражений
        elif isinstance(expr, bool):
            return expr
        elif isinstance(expr, (int, float)):
            return expr
        elif isinstance(expr, str):
            # Для строковых литералов и переменных
            if expr.startswith("'") and expr.endswith("'"):
                # Это строковый литерал
                return expr[1:-1]
            elif expr in self.environment:
                # Это переменная
                return self.environment[expr]
            else:
                # Неизвестная переменная
                raise Exception(f"Неопределенная переменная: {expr}")
        
        # Если ничего не подошло
        return expr
    
    def perform_binary_operation(self, operator, left, right):
        """
        Выполняет бинарную операцию.
        
        Args:
            operator: Оператор (+, -, *, /, ==, и т.д.)
            left: Значение левого операнда
            right: Значение правого операнда
            
        Returns:
            Результат операции
        """
        # Арифметические операции
        if operator == '+':
            return left + right
        elif operator == '-':
            return left - right
        elif operator == '*':
            return left * right
        elif operator == '/':
            return left / right
        
        # Операции сравнения
        elif operator == '==':
            return left == right
        elif operator == '/=':
            return left != right
        elif operator == '<':
            return left < right
        elif operator == '<=':
            return left <= right
        elif operator == '>':
            return left > right
        elif operator == '>=':
            return left >= right
        
        # Логические операции
        elif operator == '.AND.':
            return left and right
        elif operator == '.OR.':
            return left or right
        elif operator == '.EQV.':
            return left == right
        elif operator == '.NEQV.':
            return left != right
        
        raise Exception(f"Неизвестный бинарный оператор: {operator}")
    
    def convert_to_type(self, value, target_type):
        """
        Преобразует значение к указанному типу.
        
        Args:
            value: Значение для преобразования
            target_type: Целевой тип (INTEGER, REAL, LOGICAL, CHARACTER)
            
        Returns:
            Преобразованное значение
        """
        if target_type == 'INTEGER':
            try:
                return int(float(value))
            except (ValueError, TypeError):
                return 0
        elif target_type == 'REAL':
            try:
                return float(value)
            except (ValueError, TypeError):
                return 0.0
        elif target_type == 'LOGICAL':
            if isinstance(value, str):
                return value.lower() in ('true', '.true.', 't', 'yes', 'y', '1')
            else:
                return bool(value)
        elif target_type == 'CHARACTER':
            return str(value)
        else:
            return value


# --- ГЛАВНАЯ ФУНКЦИЯ ---

def run_fortran_interpreter(source_code):
    """
    Запускает интерпретацию Fortran-программы.
    
    Args:
        source_code: Исходный код программы
    """
    try:
        # Лексический анализ
        lexer = Lexer(source_code)
        
        # Синтаксический анализ
        parser = Parser(lexer)
        ast = parser.parse()
        
        # Семантический анализ
        semantic_analyzer = SemanticAnalyzer()
        ast = semantic_analyzer.analyze(ast)
        
        # Интерпретация
        interpreter = FortranInterpreter()
        interpreter.interpret(ast)
        
        return True
    except Exception as e:
        print(f"Ошибка: {e}")
        return False

def run_simple_fortran_program(source_code):
    """
    Запускает простую Fortran-программу через интерпретатор.
    
    Args:
        source_code: Исходный код программы
    """
    # Создаем упрощенное AST напрямую
    program_ast = {
        'type': 'program',
        'name': 'main',
        'declarations': [
            {
                'type': 'declaration',
                'data_type': 'INTEGER',
                'variables': [
                    {
                        'type': 'initialized_variable',
                        'name': 'n',
                        'value': 6
                    }
                ]
            },
            {
                'type': 'declaration',
                'data_type': 'LOGICAL',
                'variables': [
                    {
                        'type': 'initialized_variable',
                        'name': 'some_bool',
                        'value': False
                    }
                ]
            }
        ],
        'statements': [
            {
                'type': 'if_statement',
                'condition': {
                    'op': '==', 
                    'left': 'some_bool', 
                    'right': True
                },
                'then_block': [
                    {
                        'type': 'print',
                        'format': '*',
                        'expressions': ["'n is divided by 3'"]
                    }
                ],
                'else_block': [
                    {
                        'type': 'print',
                        'format': '*',
                        'expressions': ["'n is not divided by 3'"]
                    }
                ]
            }
        ]
    }
    
    # Интерпретируем AST
    interpreter = FortranInterpreter()
    interpreter.interpret(program_ast)

# Запуск нашей программы
# run_simple_fortran_program("program main...")

class SimpleInterpreter:
    def __init__(self):
        self.variables = {}
    
    def run(self, code):
        # Разбиваем код на строки
        lines = code.strip().split('\n')
        
        # Обработка объявлений и присваиваний
        for line in lines:
            line = line.strip()
            
            # Объявление INTEGER с инициализацией
            if 'integer' in line.lower() and '=' in line:
                parts = line.split('=')
                var_name = parts[0].split('::')[1].strip()
                value = int(parts[1].strip())
                self.variables[var_name] = value
            
            # Объявление LOGICAL с инициализацией
            elif 'logical' in line.lower() and '=' in line:
                parts = line.split('=')
                var_name = parts[0].split('::')[1].strip()
                value_str = parts[1].strip().lower()
                if 'true' in value_str:
                    value = True
                else:
                    value = False
                self.variables[var_name] = value
        
        # Поиск блока IF-THEN-ELSE
        in_if_block = False
        condition_true = False
        
        for i, line in enumerate(lines):
            line = line.strip().lower()
            
            # Начало IF блока
            if line.startswith('if') and 'then' in line:
                in_if_block = True
                
                # Извлекаем условие
                condition_str = line.split('(')[1].split(')')[0]
                
                # Проверяем условие (упрощенно)
                if 'some_bool' in condition_str and 'true' in condition_str:
                    if self.variables.get('some_bool') == True:
                        condition_true = True
                elif 'some_bool' in condition_str and 'false' in condition_str:
                    if self.variables.get('some_bool') == False:
                        condition_true = True
            
            # Блок THEN
            elif in_if_block and condition_true and 'print' in line:
                # Находим строку для вывода
                if '*' in line and "'" in line:
                    # Извлекаем строковый литерал
                    start = line.find("'") + 1
                    end = line.rfind("'")
                    if start < end:
                        message = line[start:end]
                        print(message)
                    else:
                        print("Ошибка при извлечении строки для печати")
                    break  # Останавливаемся после выполнения оператора PRINT
            
            # Блок ELSE
            elif in_if_block and not condition_true and 'else' in line:
                for j in range(i+1, len(lines)):
                    next_line = lines[j].strip().lower()
                    if 'print' in next_line:
                        # Находим строку для вывода
                        if '*' in next_line and "'" in next_line:
                            start = next_line.find("'") + 1
                            end = next_line.rfind("'")
                            if start < end:
                                message = next_line[start:end]
                                print(message)
                            else:
                                print("Ошибка при извлечении строки для печати")
                        break  # Останавливаемся после выполнения оператора PRINT
                break  # Останавливаемся после обработки блока ELSE



# fortran_code = '''
# program main
#  integer :: n = 6
#  logical :: some_bool = .true.
#  CHARACTER :: ok = 'n is divided by 3'
 
#  if(some_bool) then
#    print *, ok
#  else
#    print *, ok
#  end if
 
# end program main
# '''

# # Запуск интерпретатора
# run_fortran_interpreter(fortran_code)

fortran_code = '''
program main
 integer :: n = 'c'
 integer :: k = 2.2
 logical :: some_bool = .false.
 
 if (some_bool) then
   print *, k
 else
   print *, 0
 end if
 
 d()
 
end program main
'''

run_fortran_interpreter(fortran_code)
# interpreter = SimpleInterpreter()
# interpreter.run(fortran_code)
