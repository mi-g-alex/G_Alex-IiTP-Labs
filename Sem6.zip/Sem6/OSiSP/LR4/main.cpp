#include <iostream>
#include <csignal>
#include <unistd.h>
#include <cstdlib>
#include <fstream>
#include <sys/wait.h>
#include <ctime>

struct ApplicationContext {
    int count;
};

ApplicationContext appContext;

void SaveContext() {
    std::ofstream file("context.dat", std::ios::binary);
    if (file) {
        file.write(reinterpret_cast<char*>(&appContext), sizeof(appContext));
    }
}

void LoadContext() {
    std::ifstream file("context.dat", std::ios::binary);
    if (file) {
        file.read(reinterpret_cast<char*>(&appContext), sizeof(appContext));
    } else {
        appContext.count = 0; // Инициализация, если файл не найден
    }
}

void SignalHandler(int signum) {
    std::cout << "Signal received: " << signum << ". Creating a child process." << std::endl;

    SaveContext();

    pid_t pid = fork();
    if (pid < 0) {
        std::cerr << "Fork failed!" << std::endl;
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        std::cout << "Child process created. Continuing execution..." << std::endl;
        while (true) {
            appContext.count++;
            SaveContext();
            std::cout << "Child count: " << appContext.count << std::endl;
            sleep(1); 
        }
    } else {
        std::cout << "Parent process exiting." << std::endl;
        exit(0); 
    }
}

int main() {
    signal(SIGINT, SignalHandler); 

    LoadContext();
    std::cout << "Starting count from: " << appContext.count << std::endl;

    while (true) {
        // Основной цикл родительского процесса
        appContext.count++;
        SaveContext();
        std::cout << "Parent count: " << appContext.count << std::endl;
        sleep(1); // Задержка в 1 секунду
    }

    return 0;
}
