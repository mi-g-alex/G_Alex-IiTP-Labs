#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>


int shared_data = 0;  
int reader_count = 0; 

pthread_mutex_t resource_mutex = PTHREAD_MUTEX_INITIALIZER; 
pthread_mutex_t reader_count_mutex = PTHREAD_MUTEX_INITIALIZER;

void *reader(void *arg) {
    int id = *(int *)arg;
    free(arg);

    while (1) {
        pthread_mutex_lock(&reader_count_mutex);
        reader_count++;
        if (reader_count == 1) {
            pthread_mutex_lock(&resource_mutex);
        }
        pthread_mutex_unlock(&reader_count_mutex);

        printf("Читатель %d читает данные: %d\n", id, shared_data);
        usleep(rand() % 1000000); 

        pthread_mutex_lock(&reader_count_mutex);
        reader_count--;
        if (reader_count == 0) {
            pthread_mutex_unlock(&resource_mutex);
        }
        pthread_mutex_unlock(&reader_count_mutex);

        usleep(rand() % 1000000); 
    }

    return NULL;
}

void *writer(void *arg) {
    int id = *(int *)arg;
    free(arg);

    while (1) {
        pthread_mutex_lock(&resource_mutex);

        shared_data++;
        printf("Писатель %d записал данные: %d\n", id, shared_data);
        usleep(rand() % 1000000); 

        pthread_mutex_unlock(&resource_mutex);

        usleep(rand() % 1000000); 
    }

    return NULL;
}

int main(int argc, const char** argv) {
    int NUM_READERS = 5;
    int NUM_WRITERS = 2;

    if (argc == 3) {
        NUM_READERS = atoi(argv[1]);
        NUM_WRITERS = atoi(argv[2]);
    }

    printf("%d читателя и %d писателя\n", NUM_READERS, NUM_WRITERS);

    sleep(3);

    pthread_t readers[NUM_READERS], writers[NUM_WRITERS];

    for (int i = 0; i < NUM_READERS; i++) {
        int *id = malloc(sizeof(int));
        *id = i + 1;
        if (pthread_create(&readers[i], NULL, reader, id) != 0) {
            perror("Ошибка создания потока читателя");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < NUM_WRITERS; i++) {
        int *id = malloc(sizeof(int));
        *id = i + 1;
        if (pthread_create(&writers[i], NULL, writer, id) != 0) {
            perror("Ошибка создания потока писателя");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < NUM_READERS; i++) {
        pthread_join(readers[i], NULL);
    }
    for (int i = 0; i < NUM_WRITERS; i++) {
        pthread_join(writers[i], NULL);
    }

    return 0;
}