#ifndef MORSE_H
#define MORSE_H

char* char_to_morse(char c);

#endif // MORSE_H
