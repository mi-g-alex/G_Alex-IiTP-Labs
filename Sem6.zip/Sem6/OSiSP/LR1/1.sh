#!/bin/sh

RESULTS_FILE="X-Cross $(date).txt"

board=("1" "2" "3" "4" "5" "6" "7" "8" "9")
player_a="✖"
player_b="◯"
current_player=$player_a
game_over=false
result_text=""

display_board() {
    clear
    echo " ${board[0]} | ${board[1]} | ${board[2]} "
    echo "-----------"
    echo " ${board[3]} | ${board[4]} | ${board[5]} "
    echo "-----------"
    echo " ${board[6]} | ${board[7]} | ${board[8]} "
}

check_win() {
    for i in 0 3 6; do
        if [ "${board[$i]}" == "${board[$((i+1))]}" ] && [ "${board[$i]}" == "${board[$((i+2))]}" ]; then
            result_text="Игрок ${board[$i]} выиграл"
            echo "Игрок ${board[$i]} выиграл"
            game_over=true
            return
        fi
    done

    for i in 0 1 2; do
        if [ "${board[$i]}" == "${board[$((i+3))]}" ] && [ "${board[$i]}" == "${board[$((i+6))]}" ]; then
            result_text="Игрок ${board[$i]} выиграл"
            echo "Игрок ${board[$i]} выиграл"
            game_over=true
            return
        fi
    done

    if [ "${board[0]}" == "${board[4]}" ] && [ "${board[0]}" == "${board[8]}" ]; then
        result_text="Игрок ${board[0]} выиграл"
        echo "Игрок ${board[0]} выиграл"
        game_over=true
        return
    fi

    if [ "${board[2]}" == "${board[4]}" ] && [ "${board[2]}" == "${board[6]}" ]; then
        result_text="Игрок ${board[2]} выиграл"
        echo "Игрок ${board[2]} выиграл"
        game_over=true
        return
    fi

    if ! [[ " ${board[@]} " =~ [1-9] ]]; then
        result_text="Ничья"
        echo "Ничья"
        game_over=true
    fi
}

save_result() {
    local result=$1
    echo "$(date): $result" >> "$RESULTS_FILE"
    echo " ${board[0]} | ${board[1]} | ${board[2]} " >> "$RESULTS_FILE"
    echo "-----------" >> "$RESULTS_FILE"
    echo " ${board[3]} | ${board[4]} | ${board[5]} " >> "$RESULTS_FILE"
    echo "-----------" >> "$RESULTS_FILE"
    echo " ${board[6]} | ${board[7]} | ${board[8]} " >> "$RESULTS_FILE"
}

display_board
while ! $game_over; do
    
    echo "Ход игрока $current_player. Введите номер клетки от 1 до 9)"
    read -n1 -r cell

    if ! [[ "$cell" =~ ^[1-9]$ ]]; then
        display_board
        echo "Некорректный ввод. Пожалуйста, введите число от 1 до 9."
        continue
    fi

    index=$((cell-1))

    if [ "${board[$index]}" == "$cell" ]; then
        board[$index]=$current_player
        check_win
        display_board

        if $game_over; then
            display_board
            check_win
            save_result "$result_text"
        else
            if [ "$current_player" == "$player_a" ]; then
                current_player="$player_b"
            else
                current_player="$player_a"
            fi
        fi
    else
        display_board
        echo "Клетка занята"
    fi
done