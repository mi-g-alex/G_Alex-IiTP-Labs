import numpy as np
import matplotlib.pyplot as plt
import csv

def load_data(filename, selected):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        headers = next(reader)
        data = []
        column = []
        if not selected:
            columns = [
                'Depression', 
                'Academic Pressure', 
                'CGPA', 
                'Study Satisfaction', 
                'Work/Study Hours', 
                'Financial Stress'
            ]
        else:
             columns = [
                'Depression', 
                'Academic Pressure', 
                'Financial Stress'
            ]
        indices = [headers.index(col) for col in columns]
        
        for row in reader:
            try:
                converted_row = [float(row[i]) for i in indices]
                data.append(converted_row)
            except (ValueError, IndexError):
                continue
    
    data_array = np.array(data)
    
    y = data_array[:, 0]
    X = data_array[:, 1:]
    
    return X, y, columns[1:]

def multiple_linear_regression(X, y):
    X_with_intercept = np.column_stack([np.ones(X.shape[0]), X])
    
    coefficients = np.linalg.inv(X_with_intercept.T @ X_with_intercept) @ X_with_intercept.T @ y
    
    intercept = coefficients[0]
    coef = coefficients[1:]
    
    return intercept, coef

def plot_all_regressions(X, y, feature_names, title_suffix=""):
    n_features = X.shape[1]
    fig, axes = plt.subplots(1, n_features, figsize=(5*n_features, 5))
    if n_features == 1:
        axes = [axes]
    
    intercept, coef = multiple_linear_regression(X, y)
    
    print(f"\nУравнение множественной регрессии{title_suffix}:")
    equation = f"y = {intercept:.2f}"
    for i, c in enumerate(coef):
        equation += f" + {c:.2f}*x{i+1}"
    print(equation)
    
    for i, (ax, feature) in enumerate(zip(axes, feature_names)):
        x = X[:, i]
        
        x = X[:, i]
        a, b = np.polyfit(x, y, 1)
        
        ax.scatter(x, y, alpha=0.5, label='Данные')
        ax.plot(x, a*x + b, color='red', label=f'y = {a:.2f}x + {b:.2f}')
        
        ax.set_xlabel(feature)
        ax.legend()
    
    plt.tight_layout()
    plt.show()

def main():
    try:
        X, y, feature_names = load_data('data.csv', False)
        
        plot_all_regressions(X, y, feature_names, " (все параметры)")
        
        X_selected, y, selected_feature_names = load_data('data-selected.csv', True)
        
        plot_all_regressions(X_selected, y, selected_feature_names, " (отобранные параметры)")
        
    except FileNotFoundError:
        print("Ошибка: файл не найден.")
    except Exception as e:
        print(f"Произошла ошибка: {str(e)}")


if __name__ == "__main__":
    main()