fun encrypt(text: String, keyEn: String, keyRu: String): String {
    val fullKeyEn = keyEn.repeat((text.length / keyEn.length) + 1).substring(0, text.length)
    val fullKeyRu = keyRu.repeat((text.length / keyRu.length) + 1).substring(0, text.length)
    return text.mapIndexed { index, char ->
        if (char.lowercaseChar() in (('a'..'z').toList() + ('а'..'я').toList())) {
            if (char.lowercaseChar() in 'a'..'z') {
                val offset = (if (char in 'A'..'Z') 'A' else 'a').code
                val keyChar = fullKeyEn[index].code
                ((char.code + keyChar - 2 * offset) % 26 + offset).toChar()
            } else {
                val offset = (if (char in 'А'..'Я') 'А' else 'а').code
                val keyChar = fullKeyRu[index].code
                ((char.code + keyChar - 2 * offset) % 33 + offset).toChar()
            }
        } else {
            char
        }
    }.joinToString("")
}

fun decrypt(text: String, keyEn: String, keyRu: String): String {
    val fullKeyEn = keyEn.repeat((text.length / keyEn.length) + 1).substring(0, text.length)
    val fullKeyRu = keyRu.repeat((text.length / keyRu.length) + 1).substring(0, text.length)
    return text.mapIndexed { index, char ->
        if (char.lowercaseChar() in (('a'..'z').toList() + ('а'..'я').toList())) {
            if (char.lowercaseChar() in 'a'..'z') {
                val offset = (if (char in 'A'..'Z') 'A' else 'a').code
                val keyChar = fullKeyEn[index].code
                ((char.code - keyChar + 52) % 26 + offset).toChar()
            } else {
                val offset = (if (char in 'А'..'Я') 'А' else 'а').code
                val keyChar = fullKeyRu[index].code
                ((char.code - keyChar + 66) % 33 + offset).toChar()
            }
        } else {
            char
        }
    }.joinToString("")
}

fun main() {
    val inp = java.io.File("input1.txt")
    val out = java.io.File("output1.txt")
    val i = inp.readLines().toMutableList()
    val keyEn = i[0]
    val keyRu = i[1]
    i.removeFirst()
    i.removeFirst()
    val text = i.joinToString()

    val encrypted = encrypt(text, keyEn, keyRu)

    val decrypted = decrypt(text, keyEn, keyRu)
    out.writeText("Encrypted: $encrypted\nDecrypted: $decrypted")
}
