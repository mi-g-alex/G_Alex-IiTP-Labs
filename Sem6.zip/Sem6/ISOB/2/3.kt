import java.util.*
import kotlin.random.Random

fun main() {
    val clientSecret = "client_pass"
    val tgsSecret = "tgs_secret"
    val serviceSecret = "service_secret"

    val authServer = AuthenticationServer(clientSecret, tgsSecret)
    val ticketServer = TicketGrantingServer(tgsSecret, serviceSecret)
    val service = ServiceServer(serviceSecret)
    val client = Client("client1", clientSecret)

    println("Успешная аутентификация:")
    val success = client.accessService(authServer, ticketServer, service, "file_service")
    println("Доступ к сервису: $success\n")

    println("Попытка доступа с неверными данными:")
    val wrongClient = Client("client1", "wrong_pass")
    val fail = wrongClient.accessService(authServer, ticketServer, service, "file_service")
    println("Доступ к сервису: $fail")
}

class AuthenticationServer(
    private val clientSecret: String,
    private val tgsSecret: String
) {
    fun requestTGT(clientId: String): Pair<String, String> {
        val sessionKey = generateKey()
        val tgtData = "$clientId:${sessionKey}:${System.currentTimeMillis()}"

        // 1. генерируем сессионый ключ и шифруем нашим паролей
        // 2. генерим тгт данные и шифруем тгс ключом
        return Pair(
            sessionKey.xor(clientSecret),  // Для клиента
            tgtData.xor(tgsSecret)        // TGT для TGS
        )
    }
}

class TicketGrantingServer(
    private val tgsSecret: String,
    private val serviceSecret: String
) {
    fun requestServiceTicket(tgt: String, authenticator: String, serviceId: String): Pair<String, String>? {
        val decryptedTGT = tgt.unxor(tgsSecret) // 5. получаем тгт данные с помощью тгт секрета
        val tgtParts = decryptedTGT.split(":")
        if (tgtParts.size != 3) return null

        val (clientId, sessionKey, timestamp) = tgtParts
        if (System.currentTimeMillis() - timestamp.toLong() > 5000) return null

        val decryptedAuth = authenticator.unxor(sessionKey) // 6. провеяем что тут клиуент
        if (decryptedAuth != clientId) return null

        val serviceSessionKey = generateKey() // 7. генериурем ключ доступа к сервисв
        val serviceTicket = "$clientId:$serviceSessionKey:${System.currentTimeMillis()}".xor(serviceSecret) // 8. генерим тикет доступа и шифруем серверным сикретом

        return Pair(
            serviceSessionKey.xor(sessionKey),  // Для клиента
            serviceTicket                        // Для сервиса
        )
    }
}

class ServiceServer(private val serviceSecret: String) {
    fun validateTicket(serviceTicket: String, authenticator: String): Boolean {
        val decryptedTicket = serviceTicket.unxor(serviceSecret)
        val ticketParts = decryptedTicket.split(":")
        if (ticketParts.size != 3) return false

        val (clientId, sessionKey, timestamp) = ticketParts
        if (System.currentTimeMillis() - timestamp.toLong() > 5000) return false

        val decryptedAuth = authenticator.unxor(sessionKey)
        return decryptedAuth == "$clientId:${System.currentTimeMillis()}"
    }
}

class Client(val id: String, private val secret: String) {
    fun accessService(
        auth: AuthenticationServer,
        tgs: TicketGrantingServer,
        service: ServiceServer,
        serviceId: String
    ): Boolean {
        val (encSessionKey, tgt) = auth.requestTGT(id)
        val sessionKey = encSessionKey.unxor(secret) // 3. получаем сессионый ключ и расшифровываем нашим паролей

        val authenticator = id.xor(sessionKey) // 4. генерим аунтентификатор на базе сессионого ключа
        val serviceTicketData = tgs.requestServiceTicket(tgt, authenticator, serviceId) ?: return false

        val (encServiceSessionKey, serviceTicket) = serviceTicketData // 9. Из ответы достаем ключ и тикет доступа к сервису
        val serviceSessionKey = encServiceSessionKey.unxor(sessionKey) // 10. получаем ключ расшифроывая нашим сессионым ключам

        val serviceAuth = "$id:${System.currentTimeMillis()}".xor(serviceSessionKey) // 11. генерим ключ дл] сервера и отпрвляетм на проверку
        return service.validateTicket(serviceTicket, serviceAuth)
    }
}

fun generateKey(): String = "key_${Random.nextInt(10000, 99999)}"

fun String.xor(key: String): String {
    val input = this.toByteArray(Charsets.UTF_8)
    val keyBytes = key.toByteArray(Charsets.UTF_8)
    return Base64.getEncoder().encodeToString(
        ByteArray(input.size) { i ->
            (input[i].toInt() xor keyBytes[i % keyBytes.size].toInt()).toByte()
        }
    )
}

fun String.unxor(key: String): String {
    val bytes = Base64.getDecoder().decode(this)
    val keyBytes = key.toByteArray(Charsets.UTF_8)
    return String(
        ByteArray(bytes.size) { i ->
            (bytes[i].toInt() xor keyBytes[i % keyBytes.size].toInt()).toByte()
        },
        Charsets.UTF_8
    )
}
