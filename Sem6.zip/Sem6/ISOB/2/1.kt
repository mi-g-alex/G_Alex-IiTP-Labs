fun main() {
    val inp = java.io.File("input.txt")
    val out = java.io.File("output.txt")
    val ruC = ('А'..'Я').toMutableList()
    val ru = ('а'..'я').toMutableList()
    ruC.add(6, 'Ё')
    ru.add(6, 'ё')
    val enC = ('A'..'Z').toList()
    val en = ('a'..'z').toList()

    println("Ключ = (- чтобы расшифровать)")
    val key = readlnOrNull()?.toInt() ?: 0

    inp.readLines().forEach { line ->
        val ans = StringBuilder()
        line.forEach { smb ->
            if(smb !in (en + enC + ru + ruC)) {
                ans.append(smb)
            } else {
                val isCap = smb in (enC + ruC)
                val isEn = smb in (enC + en)
                val c = if (isEn) {
                    if (isCap) {
                        enC[(smb.code - enC[0].code + key + 10 * en.size) % en.size]
                    } else {
                        en[(smb.code - en[0].code + key + 10 * en.size) % en.size]
                    }
                } else {
                    if (isCap) {
                        ruC[(smb.code - ruC[0].code + key + 10 * ru.size) % ru.size]
                    } else {
                        ru[(smb.code - ru[0].code + key + 10 * ru.size) % ru.size]
                    }
                }
                ans.append(c)
            }
        }
        out.writeText(ans.toString())
    }
}
