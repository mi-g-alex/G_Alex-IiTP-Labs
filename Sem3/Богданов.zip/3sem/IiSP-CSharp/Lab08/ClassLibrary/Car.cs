﻿namespace ClassLibrary
{
    public class Car
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public int TechnicalInspectionYear { get; set; }
    }
}