from sympy import symbols

interval = (-10, 10)

a = -19.79970000
b = 28.937800000
c = 562.83300000

x = symbols('x')
y = x ** 3 + a * x ** 2 + b * x + c
