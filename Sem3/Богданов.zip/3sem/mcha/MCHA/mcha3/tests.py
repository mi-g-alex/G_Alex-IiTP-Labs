from sympy import symbols

x = symbols('x')

interval = (-10, 10)

y_1 = x ** 2 - 0.9 * x - 0.36

y_2 = 4 * x ** 2 + 16 * x + 16

y_3 = x ** 4 - 2 * x ** 3 - 7 * x ** 2 + 8 * x + 1
