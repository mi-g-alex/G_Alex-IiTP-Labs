#include <iostream>

long long start(std::string x) {
        return (std::stoll(x) + 1) / 10;
}