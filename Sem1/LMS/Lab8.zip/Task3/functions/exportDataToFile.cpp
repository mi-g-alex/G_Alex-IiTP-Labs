#include <fstream>
#include "../functions.h"

//std::ofstream out("../Task3/files/DB.out");

void exportData(long long i, DB x) {
/*    out << "Struct " << i << ":"
        << "\nWorkshop: " << db[i].workshop
        << "\nName: " << db[i].name
        << "\nNumber: " << db[i].number << "\n\n";*/
}
