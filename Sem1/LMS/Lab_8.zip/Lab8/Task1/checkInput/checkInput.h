#ifndef LAB5_CHECKINPUT_H
#define LAB5_CHECKINPUT_H


bool isItNumber(char);
long double checkInput(long double);
long long checkInput(long long);


#endif //LAB5_CHECKINPUT_H
