#ifndef LAB5_CHECKINPUT_H
#define LAB5_CHECKINPUT_H


long long checkInput(long long);
long double checkInput(long double type);


#endif //LAB5_CHECKINPUT_H
