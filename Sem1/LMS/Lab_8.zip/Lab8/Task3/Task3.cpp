#include <cstdio>
#include "functions/DB.h"

void start();

DB* db;

FILE *f;

int main() {
     start();
}