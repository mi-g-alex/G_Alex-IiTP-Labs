#ifndef LAB6_FORSTART_H
#define LAB6_FORSTART_H

bool toDoTask1(char *, long long);
void toDoTask2(char*, long long);
void toDoTask3(char**, long long*, long long);
void toDoTask4(std::string&);
void toDoTask5();
void toDoTask6();
void toDoTask7();
void toDoTask8();

#endif
