import by.g_alex.task3
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.RepeatedTest
import org.junit.jupiter.api.Test
import java.io.ByteArrayOutputStream
import java.io.PrintStream
import kotlin.random.Random
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class Task3Test {

    private val outContent = ByteArrayOutputStream()
    private val errContent = ByteArrayOutputStream()
    private val originalOut = System.out
    private val originalErr = System.err

    val rand = Random(10000000)

    @BeforeEach
    fun setUp() {
        System.setOut(PrintStream(outContent))
        System.setErr(PrintStream(errContent))
    }

    @AfterEach
    fun tearDown() {
        System.setOut(originalOut)
        System.setErr(originalErr)
    }

//    @Test
//    fun `Test output work`() {
//        val inContent = "10 10".byteInputStream()
//        System.setIn(inContent)
//
//        task3()
//
//        val result = outContent.toString()
//        assertTrue(result.isNotBlank())
//    }

    @Test
    fun `Test output work`() {
        val a: Double = 987654321123456789.0
        val b: Double = 987654321123456789.0
        val inContent = "$a $b".byteInputStream()
        System.setIn(inContent)

        task3()

        val result = outContent.toString()
        assertEquals("${a * b}", result.lines()[0])
    }

    @RepeatedTest(100)
    fun `Test 100 times correctly`() {
        val a = rand.nextDouble()
        val b = rand.nextDouble()
        val inContent = "$a $b".byteInputStream()
        System.setIn(inContent)

        task3()
        val result = outContent.toString()
        assertEquals((a * b).toString(), result.lines()[0])
    }

    @Test
    fun `Test a less than 0`() {
        val a = -1
        val b = rand.nextDouble()

        val inContent = "$a $b".byteInputStream()
        System.setIn(inContent)

        task3()
        val result = outContent.toString()
        assertEquals("Wrong value of `a`. Should be greater than zero", result.lines()[0])
    }

    @Test
    fun `Test a not number`() {
        val a = "aaa"
        val b = rand.nextDouble()

        val inContent = "$a $b".byteInputStream()
        System.setIn(inContent)

        task3()
        val result = outContent.toString()
        assertEquals("Wrong `a` format", result.lines()[0])
    }

    @Test
    fun `Test b less than 0`() {
        val a = rand.nextDouble()
        val b = -1

        val inContent = "$a $b".byteInputStream()
        System.setIn(inContent)

        task3()
        val result = outContent.toString()
        assertEquals("Wrong value of `b`. Should be greater than zero", result.lines()[0])
    }

    @Test
    fun `Test b not number`() {
        val a = rand.nextDouble()
        val b = "aaa"

        val inContent = "$a $b".byteInputStream()
        System.setIn(inContent)

        task3()
        val result = outContent.toString()
        assertEquals("Wrong `b` format", result.lines()[0])
    }

    @Test
    fun `Test a empty`() {
        val a = ""
        val b = rand.nextDouble()

        val inContent = "$a $b".byteInputStream()
        System.setIn(inContent)

        task3()
        val result = outContent.toString()
        assertEquals("Wrong `a` format", result.lines()[0])
    }

    @Test
    fun `Test b empty`() {
        val a = rand.nextDouble()

        val inContent = "$a".byteInputStream()
        System.setIn(inContent)

        task3()
        val result = outContent.toString()
        assertEquals("Wrong `b` format", result.lines()[0])
    }

    @Test
    fun `Test empty input`() {
        val inContent = "".byteInputStream()
        System.setIn(inContent)
        task3()
        val result = outContent.toString()
        assertEquals("Empty input", result.lines()[0])
    }

}