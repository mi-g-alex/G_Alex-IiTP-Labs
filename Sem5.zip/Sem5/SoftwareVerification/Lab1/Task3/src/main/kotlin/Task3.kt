package by.g_alex

import java.util.*

fun task3() {

    var a: Double
    var b: Double

    val scanner = Scanner(System.`in`)
    val rdl = if(scanner.hasNext()) {
        scanner.nextLine().ifBlank {
            println("Empty input")
            return
        }
    } else {
        println("Empty input")
        return
    }

    val input = rdl.split(' ')

    try {
        a = input[0].toDouble()
    } catch (e: Exception) {
        println("Wrong `a` format")
        return
    }
    try {
        b = input[1].toDouble()
    } catch (e: Exception) {
        println("Wrong `b` format")
        return
    }

    if (a <= 0) {
        println("Wrong value of `a`. Should be greater than zero")
        return
    }
    if (b <= 0) {
        println("Wrong value of `b`. Should be greater than zero")
        return
    }

    val ans = a + b

    println(ans)
}

fun main() {
    while (true) {
        println("Input a and b throw space in one line")
        task3()
    }
}