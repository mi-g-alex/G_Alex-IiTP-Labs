import java.io.File

fun main(args: Array<String>) {
    task5(args)
}

fun task5(args: Array<String>) {
    if (args.size != 2) {
        println("Usage: java -jar <Program> <directory> <extension>")
        return
    }

    val folder = File(args[0])
    val extension = args[1]

    var exist = false;

    if (!folder.exists() || !folder.isDirectory) {
        println("The provided directory does not exist or is not a directory.")
        return
    }

    folder.walkTopDown().forEach { file ->
        if (file.isFile && file.extension == extension) {
            exist = true
            println(file.absolutePath)
        }
    }

    if(!exist) {
        println("No files with extension: $extension.")
    }
}
