import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import java.io.ByteArrayOutputStream
import java.io.PrintStream
import kotlin.test.Test
import kotlin.test.assertEquals

class Task5Tests {

    private val outContent = ByteArrayOutputStream()
    private val errContent = ByteArrayOutputStream()
    private val originalOut = System.out
    private val originalErr = System.err

    @BeforeEach
    fun setUp() {
        System.setOut(PrintStream(outContent))
        System.setErr(PrintStream(errContent))
    }

    @AfterEach
    fun tearDown() {
        System.setOut(originalOut)
        System.setErr(originalErr)
    }

    @Test
    fun `Test wrong directory path`() {
        task5(arrayOf("C:/Wrong path", "kr"))
        val result = outContent.toString()
        assertEquals("The provided directory does not exist or is not a directory.", result.lines()[0])
    }

    @Test
    fun `Test wrong arguments`() {
        task5(arrayOf("C:/Wrong path"))
        task5(arrayOf())
        val result = outContent.toString()
        assertEquals("Usage: java -jar <Program> <directory> <extension>", result.lines()[0])
        assertEquals("Usage: java -jar <Program> <directory> <extension>", result.lines()[1])
    }

    @Test
    fun `Test kt files`() {
        task5(arrayOf("/Users/alex-gorgun/Desktop/Study/SoftwareVerification", "kt"))
        val result = outContent.toString()
        assertEquals(12, result.lines().size - 1)
    }

    @Test
    fun `Test no files`() {
        task5(arrayOf("/Users/alex-gorgun/Desktop/Study/SoftwareVerification", "txt8"))
        val result = outContent.toString()
        assertEquals("No files with extension: txt8.", result.lines()[0])
    }

}