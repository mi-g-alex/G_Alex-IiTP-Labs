package by.g_alex

fun task1() {
    val str = buildString {
        append("Hello, World!\n")
        append("And hi again!\n")
        repeat((5..50).random()) {
            append('!')
        }
    }

    println(str)
}

fun main() {
    task1()
}