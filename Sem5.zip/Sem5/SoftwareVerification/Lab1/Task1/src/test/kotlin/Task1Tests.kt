import by.g_alex.task1
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.RepeatedTest
import org.junit.jupiter.api.Test
import java.io.ByteArrayOutputStream
import java.io.PrintStream
import kotlin.test.assertNotEquals

class Task1Tests {

    private val outContent = ByteArrayOutputStream()
    private val errContent = ByteArrayOutputStream()
    private val originalOut = System.out
    private val originalErr = System.err

    @BeforeEach
    fun setUp() {
        System.setOut(PrintStream(outContent))
        System.setErr(PrintStream(errContent))
    }

    @AfterEach
    fun tearDown() {
        outContent.reset()
        System.setOut(originalOut)
        System.setErr(originalErr)
    }

    @Test
    fun `Test output work`() {
        task1()
        val result = outContent.toString()
        assertNotEquals(true, result.isBlank())
    }

    @Test
    fun `Output start with Hello World and hi again`() {
        task1()
        val result = outContent.toString()
        val msg2lns = result.lines()[0] + "\n" + result.lines()[1] + "\n"
        assertEquals("Hello, World!\nAndhiagain!\n", msg2lns, "Should start with \nHello, World!\n" +
                "Andhiagain!\n")
    }

    @Test
    fun `Output has 3 lines`() {
        task1()
        val result = outContent.toString()
        println(result.lines())
        assertEquals(3, result.count { it == '\n' })
    }

    private fun `Number of !`(result: String): Int {
        outContent.reset()
        return result.count { it == '!' }
    }

    @RepeatedTest(400)
    fun `Output end with from 5 to 50 !`() {
        task1()
        val result = outContent.toString().lines()[2]
        assertEquals(true, `Number of !`(result) in (5..50))
        assertEquals(`Number of !`(result), result.length)
    }

    @Test
    fun `Test random with 400 repeats`() {

        val setOfAns = mutableSetOf<Int>()

        repeat(400) {
            task1()
            val result = outContent.toString().lines()[2]
            outContent.reset()
            val ans = `Number of !`(result)
            setOfAns.add(ans)
            assertEquals(true, ans in (5..50))
        }

        assertEquals(true, setOfAns.size > 10)
    }

}