import by.g_alex.task4
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import java.io.File

class Task4Test {

    private val fileName = "table_gradient.html"

    @BeforeEach
    fun setUp() {
        task4()
    }

    @AfterEach
    fun tearDown() {
        val file = File(fileName)
        if (file.exists()) {
            file.delete()
        }
    }

    @Test
    fun `Test file creation`() {
        val file = File(fileName)
        assertTrue(file.exists(), "File should exist")
    }

    @Test
    fun `Test file is not empty`() {
        val file = File(fileName)
        assertTrue(file.length() > 0, "File should not be empty.")
    }

    @Test
    fun `Test file contains table`() {
        val fileContent = File(fileName).readText()
        assertTrue(fileContent.contains("<table"), "File should include <table>.")
        assertTrue(fileContent.contains("</table>"), "File should include close </table>.")
    }

    @Test
    fun `Test gradient from white to black in table rows`() {
        val fileContent = File(fileName).readText().lines()
        val color = "rgb(255, 255, 255);"
        var startIndex = fileContent.indexOfFirst { it.contains(color) }

        for (i in (0..254).reversed()) {
            val color = "rgb($i, $i, $i);"
            assertTrue(fileContent.indexOfFirst { it.contains(color) } > 0)
            val i = fileContent.indexOfFirst { it.contains(color) }
            assertTrue(i - startIndex == 1, "$i, $startIndex")
            startIndex = i
        }
    }
}
