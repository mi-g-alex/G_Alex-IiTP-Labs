package by.g_alex

import java.io.File

fun task4() {
    val stringBuilder = StringBuilder()
    stringBuilder.append(
        """
        <html>
        <head>
            <style>
                table {
                    width: 20%;
                    border-collapse: collapse;
                }
                td {
                    height: 2px;
                }
            </style>
        </head>
        <body>
            <table>

        """.trimIndent()
    )

    for (i in (0..255 step 255).reversed()) {
        val color = "rgb($i, $i, $i)"
        stringBuilder.append("<tr style=\"background-color: $color;\"><td></td></tr>\n")
    }

    stringBuilder.append(
        """
            </table>
        </body>
        </html>
    """.trimIndent()
    )

    saveHtmlToFile(stringBuilder.toString(), "table_gradient.html")
}

fun saveHtmlToFile(content: String, fileName: String) {
    File(fileName).writeText(content)
}

fun main() {
    task4()
}
