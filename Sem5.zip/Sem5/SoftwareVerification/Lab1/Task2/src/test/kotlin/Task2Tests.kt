import by.g_alex.task2
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import java.io.ByteArrayOutputStream
import java.io.PrintStream
import kotlin.test.assertEquals
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

class Task2Tests {

    private val outContent = ByteArrayOutputStream()
    private val errContent = ByteArrayOutputStream()
    private val originalOut = System.out
    private val originalErr = System.err

    @BeforeEach
    fun setUp() {
        System.setOut(PrintStream(outContent))
        System.setErr(PrintStream(errContent))
    }

    @AfterEach
    fun tearDown() {
        System.setOut(originalOut)
        System.setErr(originalErr)
    }

    private val testContent = """
            Sasha Gorgun 19
            Daniil Shumski 22
            Govsha Uliana 21
    """.trimIndent()

    @Test
    fun `Test output work`() {
        val inContent = testContent.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()
        assertNotEquals(true, result.isBlank())
    }

    @Test
    fun `Test valid data input`() {
        val inContent = testContent.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()
        assertTrue(result.startsWith(testContent))
    }

    @Test
    fun `Test valid average output`() {
        val inContent = testContent.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()
        assertEquals(result.lines()[result.lines().count() - 2], "Average: 21.33")
    }

    @Test
    fun `Test only age input`() {
        val testCnt = "  19"
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("firstName format error", result.lines()[0])
    }

    @Test
    fun `Test empty first name data input`() {
        val testCnt = " Gorgun 19"
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("firstName format error", result.lines()[0])
    }

    @Test
    fun `Test empty last name data input`() {
        val testCnt = "Alex  19"
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("lastName format error", result.lines()[0])
    }

    @Test
    fun `Test empty age input`() {
        val testCnt = "Alex Gorgun "
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("Wrong format. Need: lastName firstName Age and age should be real", result.lines()[0])
    }

    @Test
    fun `Test age less than 0`() {
        val testCnt = "Alex Gorgun -1"
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("age must be between 0 and 100", result.lines()[0])
    }

    @Test
    fun `Test age greater than 100`() {
        val testCnt = "Alex Gorgun 101"
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("age must be between 0 and 100", result.lines()[0])
    }

    @Test
    fun `Test double age`() {
        val testCnt = "Alex Gorgun 91.1"
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("Wrong format. Need: lastName firstName Age and age should be real", result.lines()[0])
    }

    @Test
    fun `Empty input`() {
        val testCnt = ""
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("No data", result.lines()[0])
    }

    @Test
    fun `Test many empty lines input`() {
        val testCnt = "\n\n\n\n\n"
        val inContent = testCnt.byteInputStream()
        System.setIn(inContent)

        task2()

        val result = outContent.toString()

        assertEquals("No data", result.lines()[0])
    }
}