package by.g_alex

import java.util.*

fun task2() {

    data class Person(
        var firstName: String,
        var lastName: String,
        var age: Int,
    ) {
        init {
            require(age in 0..100, { "age must be between 0 and 100" })
            require(Regex("^[A-Z][a-z]+$").containsMatchIn(firstName)) { "firstName format error"}
            require(Regex("^[A-Z][a-z]+$").containsMatchIn(lastName)) { "lastName format error"}

        }

        override fun toString(): String {
            return "$firstName $lastName $age"
        }
    }

    fun String.mapToPerson(): Person {
        val tmp = this.split(' ')
        return Person(
            firstName = tmp[0],
            lastName = tmp[1],
            age = tmp[2].toInt()
        )
    }

    val scanner = Scanner(System.`in`)

    val listOfData = mutableListOf<Person>()

    while (scanner.hasNextLine()) {
        val line = scanner.nextLine()
        if(line.isEmpty()) continue
        try {
            listOfData += line.mapToPerson()
        } catch (e: IndexOutOfBoundsException) {
            println("Wrong format. Need: lastName firstName Age and age should be real")
            continue
        } catch (e: NumberFormatException) {
            println("Wrong format. Need: lastName firstName Age and age should be real")
            continue
        } catch (e: IllegalArgumentException) {
            println(e.message)
            continue
        }
    }

    if(listOfData.isEmpty()) {
        println("No data")
        return
    }

    var ans = ""

    listOfData.forEach { person ->
        ans += person.toString() + "\n"
    }

    println(ans)

    val min = listOfData.minOf { it.age }

    val max = listOfData.maxOf { it.age }

    val avg = listOfData.sumOf { it.age }.toDouble() / listOfData.size.toDouble()

    println("Min age: $min")
    println("Max age: $max")
    println("Average: ${String.format("%.2f", avg)}")

}

fun main() {
    task2()
}