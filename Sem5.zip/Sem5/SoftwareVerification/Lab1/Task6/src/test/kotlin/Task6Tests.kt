import by.g_alex.downloadFile
import org.junit.jupiter.api.*
import org.junit.jupiter.api.io.TempDir
import java.io.File
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class DownloadFileTest {

    @TempDir
    lateinit var tempDir: File

    @Test
    fun `Test successful file download`() {
        val fileUrl = "https://www.bsuir.by/m/12_100229_1_185586.pdf"
        val testFileName = "12_100229_1_185586.pdf"
        val args = arrayOf(fileUrl, tempDir.absolutePath)

        downloadFile(args)

        val outputFile = File(tempDir, testFileName)
        assertTrue(outputFile.exists())
        assertTrue(outputFile.length() > 0)
    }

    @Test
    fun `Test file already exists`() {
        val testFileName = "12_100229_1_185586.pdf"
        val existingFile = File(tempDir, testFileName)
        existingFile.writeText("Existing content")

        val fileUrl = "https://www.bsuir.by/m/$testFileName"
        val args = arrayOf(fileUrl, tempDir.absolutePath)

        downloadFile(args)

        assertEquals("Existing content", existingFile.readText())
    }

    @Test
    fun `Test folder doesn't exist`() {
        val invalidFolderPath = "~/NotFolder"
        val fileUrl = "https://www.bsuir.by/m/12_100229_1_185586.pdf"
        val args = arrayOf(fileUrl, invalidFolderPath)

        val output = captureOutput { downloadFile(args) }

        assertTrue(output.contains("Folder doesn't exist or not directory"))
    }

    @Test
    fun `Test incorrect URL`() {
        val invalidUrl = "https://www.bsuir.by/m/12_100229_1_18558.pdf/"
        val args = arrayOf(invalidUrl, tempDir.absolutePath)

        val output = captureOutput { downloadFile(args) }

        assertTrue(output.contains("Can't extract file name from URL"))
    }

    private fun captureOutput(action: () -> Unit): String {
        val outputStream = java.io.ByteArrayOutputStream()
        System.setOut(java.io.PrintStream(outputStream))
        action.invoke()
        return outputStream.toString()
    }
}
