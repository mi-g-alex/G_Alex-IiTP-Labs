package by.g_alex

import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException

fun main(args: Array<String>) {
    downloadFile(args)
}

fun downloadFile(args: Array<String>) {

    if (args.size != 2) {
        println("Using: <URL> <path_to_folder>")
        return
    }

    val fileUrl = args[0]
    val saveDirectory = args[1]

    try {
        val url = URL(fileUrl)

        val directory = File(saveDirectory)
        if (!directory.exists() || !directory.isDirectory) {
            println("Folder doesn't exist or not directory: $saveDirectory")
            return
        }

        val fileName = url.path.substringAfterLast("/")
        if (fileName.isEmpty()) {
            println("Can't extract file name from URL: $fileUrl")
            return
        }

        val outputFile = File(directory, fileName)

        // Проверка на существование файла
        if (outputFile.exists()) {
            println("File exists: ${outputFile.absolutePath}")
            return
        }

        try {
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 5000
            connection.readTimeout = 5000

            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                println("Can't download file. Error code: ${connection.responseCode}")
                return
            }

            connection.inputStream.use { input ->
                outputFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

        } catch (e: UnknownHostException) {
            println("Server connection error")
            return
        } catch (e: IOException) {
            println("Download file error: ${e.message}")
            return
        }

        println("File saved: ${outputFile.absolutePath}")

    } catch (e: Exception) {
        println("Something went wrong: ${e.message}")
        e.printStackTrace()
    }

}
