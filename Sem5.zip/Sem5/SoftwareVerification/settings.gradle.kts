plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}
rootProject.name = "SoftwareVerification"
include("Lab1")
include("Lab1:Task1")
findProject(":Lab1:Task1")?.name = "Task1"
include("Lab1:Task2")
findProject(":Lab1:Task2")?.name = "Task2"
include("Lab1:Task3")
findProject(":Lab1:Task3")?.name = "Task3"
include("Lab1:Task4")
findProject(":Lab1:Task4")?.name = "Task4"
include("Lab1:Task5")
findProject(":Lab1:Task5")?.name = "Task5"
include("Lab1:Task6")
findProject(":Lab1:Task6")?.name = "Task6"
