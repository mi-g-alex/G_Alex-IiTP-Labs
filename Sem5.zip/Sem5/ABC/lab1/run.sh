#!/bin/bash

cd $(dirname $0)/src
nasm -f bin main.asm -o bootloader.bin 
qemu-system-i386 bootloader.bin -monitor stdio
rm bootloader.bin