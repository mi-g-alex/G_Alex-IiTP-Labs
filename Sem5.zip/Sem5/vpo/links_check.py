import requests
from bs4 import BeautifulSoup

def extract_links_and_save(url, all_links_filename, unique_links_filename):
    try:
        # Выполняем HTTP GET-запрос к указанному URL
        response = requests.get(url)
        # Проверяем, что запрос выполнен успешно
        response.raise_for_status()
        
        # Создаем объект BeautifulSoup для парсинга полученного HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Находим все элементы <a> и извлекаем значения атрибута href
        links = [a.get('href') for a in soup.find_all('a', href=True)]
        
        # Записываем все извлеченные ссылки в файл
        with open(all_links_filename, 'w') as file:
            for link in links:
                file.write(link + '\n')
        
        # Используем множество для хранения уникальных ссылок
        unique_links = set(links)
        
        # Записываем уникальные ссылки с кодом состояния в отдельный файл
        with open(unique_links_filename, 'w') as file:
            for link in unique_links:
                try:
                    # Получим HTTP-код статус для каждой уникальной ссылки
                    link_response = requests.get(link)
                    status_code = link_response.status_code
                    print("Протестирована", link)
                except requests.RequestException:
                    status_code = 'Ошибка'
                
                # Записываем ссылку с её статусом в файл
                file.write(f"{status_code} {link}\n")
        
        print(f"Все ссылки сохранены в {all_links_filename}")
        print(f"Уникальные ссылки сохранены в {unique_links_filename}")
    
    except requests.exceptions.RequestException as e:
        print(f"Ошибка при выполнении запроса: {e}")

# Пример использования
url = 'https://www.hse.ru'
all_links_filename = 'all_links.txt'
unique_links_filename = 'unique_links.txt'
extract_links_and_save(url, all_links_filename, unique_links_filename)